<?php 
session_start(); 
// ข้อมูลของคนที่เข้ามา

// try {
//   if (!isset($_SESSION['login'])) {
//     header("Location: ../../index.php?error=เกินข้อผิดพราด!");
// }
// }
// catch(Exception $e) {
//   echo "Access denied: No Permission to view this page";
//   exit(1);
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "link.php"?>
  <?php include "../../query.php" ?>

 
<title>ระบบยืมของภาควิชาคอม</title>
<script>
function showHint(str) {
    if (str.length == 0) {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "./page_mamage/page_gethint.php?q=" + str, true);
        xmlhttp.send();
    }
}
</script>
</head>

<body id="page-top">
  <div id="wrapper" >

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
      <?php include "logout3.php" ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content" >

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">


        <!-- เริ่ม -->
            <div class="row" >

                  <!-- ส่วนของคำว่า "หน้าหลัก" -->
                <div class="col-xl-12 col-12 mb-4"  >
                    <div class="card" >
                        <div class="card-header card-bg  header-text-color"  style="background-color:#fff;">
                            อุปกรณ์
                        </div>
                        
                        
                    </div>
                </div>
                  <!-- จบ ส่วนของคำว่า "หน้าหลัก" -->
                 
              
            </div>
        <!-- จบ -->
  
<!-- <p><b>Start typing a name in the input field below:</b></p>
<form>
First name: <input type="text" onkeyup="showHint(this.value)">
</form>
<p>Suggestions: <span></span></p> -->

         <!-- ส่วนของตาราง รายการขอยื่ม -->
         <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="h5 m-0 font-weight-bold text-primary">รายการอุปกรณ์ </h6>
                    <a href="page_borrow_confirmation.php"><button  type="button" style="float:right;" class="btn btn-success" data-toggle="modal" data-target="#modal-1"> <?php echo count($_SESSION['basket']);?> <i class="fas fa-shopping-cart"></i> </button></a>
                  <div class="col-3">
                  เลือกหมวดหมู่
                    <select class="form-control" id="cars" onchange="showHint(this.value)" >
                      <option value="All">ทั้งหมด</option>
                      <?php 
                        $stml = get_category();
                        while ($get_category = $stml->fetch(PDO::FETCH_OBJ)){?>
                        <option value="<?php echo $get_category->cid ?>" <?php if(isset($_SESSION['category'])){if($_SESSION['category'] == $get_category->cid){echo "selected";}}?>><?php echo $get_category->cName ?> </option>
                      <?php
                      }  
                      ?>
                    </select>
                  </div>
                </div>
                <div class="card-body">
                  <div  id="txtHint" class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <colgroup>
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                      </colgroup>
                      <thead>
                        <tr>
                          <th>ภาพ</th>
                          <th>ชื่ออุปกรณ์</th>
                          <th>หมวดหมู่</th>
                          <th>จำนวนที่เหลือ</th>
                          <th>รายละเอียด</th>
                          <th style="text-align:center;">ทำรายการ</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <th>ภาพ</th>
                          <th>ชื่ออุปกรณ์</th>
                          <th>หมวดหมู่</th>
                          <th>จำนวนที่เหลือ</th>
                          <th>รายละเอียด</th>
                          <th style="text-align:center;">ทำรายการ</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        <?php
                           if(isset($_SESSION['category'])){
                              if($_SESSION['category']=='All'){
                                $stml = get_all_page($_SESSION['login']['status'],$_SESSION['login']['isAdmin']);
                              }else{
                                $stml = get_page($_SESSION['login']['status'],$_SESSION['login']['isAdmin'],$_SESSION['category']);
                              }
                            }else{
                            $stml = get_all_page($_SESSION['login']['status'],$_SESSION['login']['isAdmin']);
                            }
                           while ($get_all_page = $stml->fetch(PDO::FETCH_OBJ)){?>
                            <tr>
                              <td><img src="<?php echo "../Admin/img_product/".$get_all_page->picPath ?>" alt="Lights" style="width:100%;max-width:100px"></td>
                              <td><?php echo $get_all_page->pName ?></td>
                              <td><?php echo $get_all_page->cName ?></td>
                              <td><?php  if($get_all_page->countS == NULL){ echo '0';}else{echo $get_all_page->countS ;} ?></td>
                              <td><?php echo $get_all_page->detail ?></td>
                              <td style="text-align:center;">
                                <button value="<?php if(isset($_SESSION['basket'][$get_all_page->pid])){echo "1" ;}else{ echo "0";}?>" type="button" class="btn <?php if(isset($_SESSION['basket'][$get_all_page->pid])){echo "btn-danger" ;}else{ echo "btn-success";}?> btn-sm " 
                                data-toggle="tooltip" title="" data-original-title="อยู่ในรายการ" 
                                onclick="<?php if(isset($_SESSION['basket'][$get_all_page->pid])){echo "del_basket" ;}else{ echo "add_basket";}?>('<?php echo $get_all_page->pid ?>','<?php echo $get_all_page->pName?>')">
                                <i class="fas fa-shopping-cart" aria-hidden="true"></i>
                              </button>
                              </td>
                            </tr>
                        <?php
                        } 
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
        <!-- จบ ส่วนของตาราง รายการรออนุมัติ-->
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 
 
</body>

</html>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<script>
  
  // ใส่สินค้าในตะกร้า
  function add_basket(pid,pname) {

swal({
      
        title: "คุณแน่ใจที่จะยืม",
        text: pname,
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        cancelButtonClass: "btn-secondary",
        confirmButtonText: "ยืนยัน",
        cancelButtonText: "ยกเลิก",
        closeOnConfirm: false,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            swal({
                title: "เพื่มใส่ตะกร้าเรียบร้อย",
                type: "success",
                confirmButtonClass: "btn-danger",
                confirmButtonText: "ตกลง",
                closeOnConfirm: false,
            });
            Add_1(pid);
            setTimeout(function() {
              location.reload();
            }, 1000);
        } else {

        }
    });
}
function Add_1(pid) {
    $.ajax({
      type: "POST",
      data: {
        pid: pid,
        basketAdd: "basketAdd"
      },
      url: "./page_mamage/basket_gethint.php",
      async: false,
      success: function(result) {}
    });
  }

// จบ_ใส่สินค้าในตะกร้า

  // ลบสินค้าในตะกร้า
  function del_basket(pid,pname) {

swal({
      
        title: "คุณแน่ใจที่จะเอาออก",
        text: pname,
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        cancelButtonClass: "btn-secondary",
        confirmButtonText: "ยืนยัน",
        cancelButtonText: "ยกเลิก",
        closeOnConfirm: false,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            swal({
                title: "เอาออกเรียบร้อย",
                type: "success",
                confirmButtonClass: "btn-danger",
                confirmButtonText: "ตกลง",
                closeOnConfirm: false,
            });
            del_1(pid);
            setTimeout(function() {
              location.reload();
            }, 1000);
        } else {

        }
    });
}
function del_1(pid) {
    $.ajax({
      type: "POST",
      data: {
        pid: pid,
        basketdel: "basketdel"
      },
      url: "./page_mamage/basket_gethint.php",
      async: false,
      success: function(result) {}
    });
  }

// จบ_ลบสินค้าในตะกร้า

</script>