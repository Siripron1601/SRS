<?php
session_start();
$DATAUSER = $_SESSION['DATAUSER'] ?? NULL;
require_once('../../view/Admin/link.php');
include("../../dbConnect.php");
$sqlHisAd = "SELECT log_order.log_id,log_order.startT,log_order.endT,dim_user.stCode,dim_user.title,
dim_user.firstname,dim_user.lastname,dim_teacher.title,dim_teacher.firstname,dim_teacher.lastname,
log_detailborrow.borrowNum,log_order.confirm_note,log_order.return_note 
FROM log_order INNER JOIN log_detailborrow ON log_order.log_id = log_detailborrow.log_orderid 
INNER JOIN dim_user ON dim_user.dim_id = log_order.dim_uid 
INNER JOIN dim_teacher ON log_order.dim_tid = dim_teacher.dim_id WHERE dim_user.status = '3' 
AND log_order.status_borrow = '4' OR dim_user.status = '3' AND log_order.status_borrow = '2'";

$TableUser = selectData($sqlHisAd);

$sqldbProduct = "SELECT * FROM db_product INNER JOIN db_serialnumber ON db_product.pid = db_serialnumber.pid";

$TabledbProduct = selectData($sqldbProduct);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "link.php" ?>
    <title>ระบบยืมของภาควิชาคอม</title>
</head>

<body id="page-top">
    <div id="wrapper">

        <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
        <?php include "logout3.php" ?>
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

            <!-- Main Content -->
            <div id="content">

                <!-- อันนี้ไว้เรียกใช้แท็บบน -->
                <?php include "Topbar.php" ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">



                    <!-- เริ่ม -->
                    <div class="row">

                        <!-- ส่วนของคำว่า "หน้าหลัก" -->
                        <div class="col-xl-12 col-12 mb-4">
                            <div class="card">
                                <div class="card-header card-bg  header-text-color" style="background-color:#fff;">
                                    หน้าประวัติการยืม

                                </div>


                            </div>
                        </div>
                        <!-- จบ ส่วนของคำว่า "หน้าหลัก" -->




                    </div>
                    <!-- จบ -->


                    <!-- ส่วนของตาราง รายการขอยื่ม -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="h5 m-0 font-weight-bold text-primary">ประวัติการยืม</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <colgroup>
                                        <col width="20">
                                        <col width="20">
                                        <col width="20">
                                        <col width="20">
                                        <col width="20">
                                        <col width="20">
                                        <col width="20">
                                        <col width="20">
                                        <col width="40">
                                    </colgroup>
                                    <thead>
                                        <tr>
                                            <th>รหัสรายการ</th>
                                            <th>วันที่ทำเรื่อง</th>
                                            <th>รหัสประจำตัว</th>
                                            <th>จำนวน</th>
                                            <th>อาจารย์ที่อนุมัติ</th>
                                            <th>หมายเหตุ</th>
                                            <th>สถานะ</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>รหัสรายการ</th>
                                            <th>วันที่ทำเรื่อง</th>
                                            <th>รหัสประจำตัว</th>
                                            <th>จำนวน</th>
                                            <th>อาจารย์ที่อนุมัติ</th>
                                            <th>หมายเหตุ</th>
                                            <th>สถานะ</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php for ($i = 0; $i < $TableUser[0]['numrow']; $i++) { ?>
                                            <tr role="row" class="odd" style="text-align:center;">
                                                <td><?php echo $TableUser[$i + 1]['log_id'] ?></td>
                                                <td><?php echo $TableUser[$i + 1]['startT'] ?></td>
                                                <td><?php echo $TableUser[$i + 1]['stCode'] ?></td>
                                                <td style="text-align:center;">
                                                    <a href="#" class="detailTool">
                                                        <button type="button" class="btn btn-warning btn-sm tt" title='รายละเอียด'>
                                                            <span>จำนวนอุปกรณ์ <?php echo $TableUser[$i + 1]['borrowNum'] ?></span>
                                                        </button>
                                                    </a>
                                                </td>
                                                <td><?php echo $TableUser[$i + 1]['title'] ?>
                                                    <?php echo $TableUser[$i + 1]['firstname'] ?>
                                                    <?php echo $TableUser[$i + 1]['lastname'] ?></td>
                                                <td><?php echo $TableUser[$i + 1]['confirm_note'] ?></td>
                                                <td><?php echo $TableUser[$i + 1]['return_note'] ?></td>

                                            </tr>
                                        <?php } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- จบ ส่วนของตาราง รายการรออนุมัติ-->
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



</body>
<div>
    <div id="modalDetail" class="modal fade">
        <form class="modal-dialog modal-lg" method="POST" action='manage.php'>
            <div class="modal-content">
                <div class="modal-header" style="background-color:#eecc0b">
                    <h4 class="modal-title" style="color:white">รายละเอียดอุปกรณ์</h4>
                </div>
                <div class="modal-body" id="addModalBody">
                    <div class="row mb-4">
                        <div class="col-sm-12">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr role="row">
                                        <th rowspan="1" colspan="1">ลำดับ</th>
                                        <th rowspan="1" colspan="1">เลขครุภัณฑ์</th>
                                        <th rowspan="1" colspan="1">ชื่ออุปกรณ์</th>
                                        <!-- <th rowspan="1" colspan="1">จำนวน</th> -->
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php for ($i = 0; $i < $TabledbProduct[0]['numrow']; $i++) { $item = $i +1;?>
                                        <tr role="row" class="odd" style="text-align:center;">
                                        <td>
                          <div align="center"><?= $item ?></div>
                        </td> <td>
                                                <?php echo $TabledbProduct[$i + 1]['serialNum'] ?></td>
                                            <td>
                                                <?php echo $TabledbProduct[$i + 1]['pName'] ?></td>
                                            <!-- <td>
                                                <?php echo $TabledbProduct[$i + 1]['detail'] ?></td> -->
                                        </tr>
                                    <?php } ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

</html>
<script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });

    $(document).ready(function() {
        console.log("ready!");
        $('.tt').tooltip({
            trigger: "hover"
        });
    });
    $(".detailTool").click(function() {


        // var detail = $(this).attr('pName');
        // alert(pName)

        // $('#pName').val(detail);

        $("#modalDetail").modal('show');
    });
</script>