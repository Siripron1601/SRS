<?php
include "../../../query.php";

if(isset($_POST['danger'])){
    det_order_user($_POST['log_id_danger']);
    header("location:../borrower.php");
}


?>