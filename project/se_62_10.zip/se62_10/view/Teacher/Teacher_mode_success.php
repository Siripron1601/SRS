<div id="success" class="modal fade">
    <form method="post" id="formEdit" name="formEdit" action="./mamage/mamage_T.php">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content2" >
                <div class="modal-header header-modal" style="background-color: #42b9d6;">
                    <h4 class="m-0 font-weight-bold text-primary2">ยืนยังการอนุมัติ</h4>
                </div>
                <div class="modal-body" id="passModalBody">
                    <div class="row mb-4">
                        
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <colgroup>
                                <col  width="20">
                                <col  width="20">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th style="text-align:center;"><h5 class="m-0 font-weight-bold text-primary">รหัสรายการ</h5></th>
                                    <th style="text-align:center;"><input type="text" class="form-control" id="id" name="delete_id" value="144" disabled></input></th>
                                </tr>
                                <tr>
                                    <th style="text-align:center;"><h5 class="m-0 font-weight-bold text-primary">วันที่ผ่านการอนุมัติ</h5></th>
                                    <th style="text-align:center;"><input type="text" class="form-control" id="data" name="delete_id" disabled></input></th>
                                </tr>
                                <tr>
                                    <th style="text-align:center;"><h5 class="m-0 font-weight-bold text-primary">รหัสประจำตัว</h5></th>
                                    <th style="text-align:center;"><input type="text" class="form-control" id="stCode" name="delete_id" disabled></input></th>
                                </tr>
                                <tr>
                                    <th style="text-align:center;"><h5 class="m-0 font-weight-bold text-primary">ผู้ทำรายการ</h5></th>
                                    <th style="text-align:center;"><input type="text" class="form-control" id="name" name="delete_id" disabled></input></th>
                                </tr>
                                <tr>
                                    <th style="text-align:center;"><h5 class="m-0 font-weight-bold text-primary">หมายเหตุ</h5></th>
                                    <th style="text-align:center;"><textarea  style="resize:none;" class="form-control rounded-0"name="suggestion" id="suggestion_1" cols="177" rows="3"></textarea></th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                        <input type="hidden" id="log_id" name="log_id"></input>
                        <input type="hidden" id="success"  name="success" value="success"></input>
                       
                    </div>
                   
                </div>
                <div class="modal-footer">
                        <button type="submit" id="edit_pass" name="edit_pass" class="btn btn-success" >ยืนยัง</button>
                        <button type="button" id="edit_pass" name="edit_pass" class="btn btn-danger "  data-dismiss="modal">ปิด</button>
                    </div>
            </div>
        </div>
    </form>
</div>
