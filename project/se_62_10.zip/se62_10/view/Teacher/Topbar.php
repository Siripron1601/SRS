


<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow" >

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">
            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['login']['firstname']." ".$_SESSION['login']['lastname']." ".$_SESSION['login']['formalId'] ?></span>
                <img class="img-profile rounded-circle" src="https://soundfc.org/wp-content/uploads/2019/03/Placeholder.jpg">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                
                <a class="dropdown-item" href="teacher_history.php">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  ประวัติการยืม
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  ออกจากระบบ
                </a>
                 <!-- เพิ่มเติม -->
                <div class="dropdown-divider">เปลี่ยนสถานะ</div>
                
                <a class="dropdown-item" href="../../Change_status.php?s=1&uid=<?php echo $_SESSION['login']['uid'];?>">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  อาจารย์
                </a>
                <a class="dropdown-item" href="../../Change_status.php?s=2&uid=<?php echo $_SESSION['login']['uid'];?>" >
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  เจ้าหน้าที่
                </a>
                <a class="dropdown-item" href="../../Change_status.php?s=3&uid=<?php echo $_SESSION['login']['uid'];?>">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  ผู้ยืม
                </a>
                <!-- เพิ่มเติม -->
              </div>
            </li>
          </ul>
        </nav>
        <!-- Logout Modal-->
        <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">ยื่นยังการออกจากระบบ</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                </button>
              </div>
              <div class="modal-body">เลือก "ออกจากระบบ" ด้านล่างหากคุณต้องการออกจากระบบ</div>
              <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">ยกเลิก</button>
                <a class="btn btn-primary" href="../../index.php" >ออกจากระบบ</a>
              </div>
            </div>
          </div>
        </div>
