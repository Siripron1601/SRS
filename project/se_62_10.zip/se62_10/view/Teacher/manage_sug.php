<?php
require_once("../../dbConnect.php");

if (isset($_POST['add'])) {
    $sug = $_POST['suggestion'];
    $startT = time();
    $datesend = date("Y-m-d");
   
    $sqluser = "INSERT INTO `log_suggestion`(`sugid`, `suggestion`,`startT`,`endT`,`date_send`) VALUES (NULL,'$sug','$startT',NULL,'$datesend')";
    echo $sqluser;
    addinsertData($sqluser);



    header("location: ./suggestion.php");
}
