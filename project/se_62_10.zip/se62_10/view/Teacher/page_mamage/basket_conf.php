<?php
session_start(); 
include "../../../query.php";
// echo $_POST['teacher_list'];
// echo $_POST['Textnote'];
$borrow_note = $_POST['Textnote'];

$stml = get_DIM_user($_SESSION['login']['uid']);
while ($get_DIM_user = $stml->fetch(PDO::FETCH_OBJ)){
    $dim_id = $get_DIM_user->dim_id;
}


if($_POST['teacher_list']>0){
    $stml = get_DIM_teacher($_POST['teacher_list']);
    while ($get_DIM_teacher = $stml->fetch(PDO::FETCH_OBJ)){
        $dim_tid = $get_DIM_teacher->dim_id;
    }
}else{
    $dim_tid = null;
}

$basket = $_SESSION['basket'] ;
Add_log_order_Teacher($dim_id,$dim_tid,$borrow_note,$basket);
unset($_SESSION['basket']);
header("location:../page_borrow.php");
// foreach ($_SESSION['basket'] as $key => $val){
//     echo $_POST['lend'.$val] ;
// }

?>