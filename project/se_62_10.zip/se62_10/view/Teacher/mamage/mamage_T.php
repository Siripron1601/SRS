<?php
include "../../../query.php";

if(isset($_POST['success'])){
    $log_id =  $_POST['log_id'];
    $data = time();
    $date_sanction = date("Y-m-d", $data);
    up_log_order_sanction($_POST['suggestion'],$date_sanction,$_POST['log_id']);
    header("location:../sample_email_success.php?log_id=$log_id");
}
if(isset($_POST['danger_2'])){
    $log_id =  $_POST['log_id_danger'];
    echo $log_id;
    up_log_order_danger($log_id,$_POST['suggestion_d'],$date_sanction);
    header("location:../sample_email_danger.php?log_id=$log_id");
 
}


?>