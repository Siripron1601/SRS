<?php 

session_start();
if(isset($_POST['basketAdd'])){
    $_SESSION['basket'][$_POST['pid']] = $_POST['pid'];
}
if(isset($_POST['basketdel'])){
    unset($_SESSION['basket'][$_POST['pid']]);
}
?>
