<?php session_start(); print_r($_SESSION['basket'])?>
<?php include "../../../query.php" ?>
<?php $_SESSION['category'] = $_GET['q']; ?>
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <colgroup>
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                      </colgroup>
                      <thead>
                        <tr>
                          <th>ภาพ</th>
                          <th>ชื่ออุปกรณ์</th>
                          <th>หมวดหมู่</th>
                          <th>จำนวนที่เหลือ</th>
                          <th>รายละเอียด</th>
                          <th style="text-align:center;">ทำรายการ</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <th>ภาพ</th>
                          <th>ชื่ออุปกรณ์</th>
                          <th>หมวดหมู่</th>
                          <th>จำนวนที่เหลือ</th>
                          <th>รายละเอียด</th>
                          <th style="text-align:center;">ทำรายการ</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        <?php
                            if($_GET['q']!='All'){
                                $stml = get_page($_SESSION['login']['status'],$_SESSION['login']['isAdmin'],$_GET['q']);
                            }else{
                                $stml = get_all_page($_SESSION['login']['status'],$_SESSION['login']['isAdmin']);
                            }
                            while ($get_all_page = $stml->fetch(PDO::FETCH_OBJ)){?>
                            <tr>
                              <td><img src="<?php echo "./img_product/".$get_all_page->picPath ?>" alt="Lights" style="width:100%;max-width:100px"></td>
                              <td><?php echo $get_all_page->pName ?></td>
                              <td><?php echo $get_all_page->cName ?></td>
                              <td><?php  if($get_all_page->countS == NULL){ echo '0';}else{echo $get_all_page->countS ;} ?></td>
                              <td><?php echo $get_all_page->detail ?></td>
                              <td style="text-align:center;">
                                <button value="<?php if(isset($_SESSION['basket'][$get_all_page->pid])){echo "1" ;}else{ echo "0";}?>" type="button" class="btn <?php if(isset($_SESSION['basket'][$get_all_page->pid])){echo "btn-danger" ;}else{ echo "btn-success";}?> btn-sm " 
                                data-toggle="tooltip" title="" data-original-title="อยู่ในรายการ" 
                                onclick="<?php if(isset($_SESSION['basket'][$get_all_page->pid])){echo "del_basket" ;}else{ echo "add_basket";}?>('<?php echo $get_all_page->pid ?>','<?php echo $get_all_page->pName?>')">
                                <i class="fas fa-shopping-cart" aria-hidden="true"></i>
                              </button>
                              </td>
                            </tr>
                        <?php
                        } 
                        ?>
                      </tbody>
                    </table>