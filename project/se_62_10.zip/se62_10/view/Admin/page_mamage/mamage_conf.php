<?php
session_start(); 
include "../../query.php";
if(isset($_POST['delete'])){
    unset($_SESSION['basket'][$_POST['key']]);
}
?>