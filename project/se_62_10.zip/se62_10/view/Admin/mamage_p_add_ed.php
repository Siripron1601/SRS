<?php
session_start(); 
include_once("../../query.php");

if(!isset($_POST['check1'])){
    $check1 = 0;
}else{
    $check1 = $_POST['check1'];
}
if(!isset($_POST['check2'])){
    $check2 = 0;
}else{
    $check2 = $_POST['check2'];
}
if(!isset($_POST['check3'])){
    $check3 = 0;
}else{
    $check3 = $_POST['check3'];
}
up_db_product($_POST['pid'],$_POST['firstname'],$_POST['category'],$_POST['details'],$_SESSION['jpg'],$check1,$check2,$check3);

unset($_SESSION["jpg"]);

header("Location: Admin_accessories.php");

?>