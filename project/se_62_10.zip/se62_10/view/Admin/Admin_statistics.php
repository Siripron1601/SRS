<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "link.php"?>
  <?php include "../../query.php"?>
  <?php
    $Y1 = $_GET['Y1'] ?? "";
    $Y2 = $_GET['Y2'] ?? "";
  ?>
<title>ระบบยืมของภาควิชาคอม</title>
</head>

<body id="page-top">
  <div id="wrapper" >

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
      <?php include "logout1.php" ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content" >

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

           

        <!-- เริ่ม -->
            <div class="row" >

                  <!-- ส่วนของคำว่า "หน้าหลัก" -->
                <div class="col-xl-12 col-12 mb-4"  >
                    <div class="card" >
                        <div class="card-header card-bg  header-text-color"  style="background-color:#fff;">
                        หน้าสถิติ
                           
                        </div>
                        
                        
                    </div>
                </div>
                  <!-- จบ ส่วนของคำว่า "หน้าหลัก" -->
            </div>
        <!-- จบ -->
       
          

           <!-- ส่วนของตาราง รายการขอยื่ม -->
         <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="h5 m-0 font-weight-bold text-primary">กราฟแสดงอุปกรณ์ที่ถูกยืม</h6>
                  <div class="col-3">
                  เลือกผลการแสดง(ปี)
                    <select class="form-control" id="cars1" onchange="myFunction1()">
                      <option value="">ทั้งหมด</option>
                      <?php
                        $stml = get_Y();
                       while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){?>
                        <option value=<?php echo $DB_user->year ?> <?php if($DB_user->year==$Y1){echo "selected" ;} ?>><?php echo $DB_user->year ?></option>
                      <?php
                      }  
                      ?>
                    </select>
                    
                  </div>
                </div>
                <div id="chart_div2" class="col-xl-1 col-12 mb-4 ">
                </div>
     
        </div>
        <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="h5 m-0 font-weight-bold text-primary">กราฟแสดงจำนวนอาจารย์อนุมัติ</h6>
                  <div class="col-3">
                  เลือกผลการแสดง(ปี)
                    <select class="form-control" id="cars2" onchange="myFunction2()">
                      <option value="">ทั้งหมด</option>
                      <?php
                      $stml = get_Y();
                       while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){?>
                        <option value=<?php echo $DB_user->year ?> <?php if($DB_user->year==$Y2){echo "selected" ;} ?>><?php echo $DB_user->year ?></option>
                      <?php
                      }  
                      ?>
                    </select>
                    
                  </div>
                </div>
                <div id="chart_div1" class="col-xl-1 col-12 mb-4">
                </div>
     
        </div>
        


        



        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 
 
</body>

</html>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<script>
function myFunction1() {
  var x1 = document.getElementById("cars1").value;
  var x2 = document.getElementById("cars2").value;
  location.href = "./Admin_statistics.php?Y1="+x1+"&Y2="+x2+"";
}
function myFunction2() {
  var x1 = document.getElementById("cars1").value;
  var x2 = document.getElementById("cars2").value;
  location.href = "./Admin_statistics.php?Y1="+x1+"&Y2="+x2+"";
}
</script>

<?php include "graph.php"?>