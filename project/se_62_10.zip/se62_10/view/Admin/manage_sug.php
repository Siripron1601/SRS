<?php
require_once("../../../se62_10/dbConnect.php");
session_start();
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $time = time();

    $sql = "UPDATE log_suggestion SET endT = $time WHERE log_suggestion.sugid = $id";

    updateData($sql);
}
