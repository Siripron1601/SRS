  <div id="numbermode_ed" class="modal fade">
    <form class="modal-dialog modal-lg " method="POST" action='mamage_p_add_2.php'>
      <div class="modal-content">
        <div class="modal-header" style="background-color:#eecc0b"><h4 class="modal-title" style="color:white">แก้ไขเลขครุภัณฑ์ </h4></div>
        <div class="modal-body" id="AddModalBody">
            <div class="row mb-4"><div class="col-xl-3 col-12 text-right">
              <span>เลขครุภัณฑ์ :</span>
            </div>
            <div class="col-xl-8 col-12">
              <input type="text" class="form-control" id="e_numbermode" name="e_numbermode" value="" maxlength="100">
            </div>
          </div>
          <input type="hidden" id="numbermode_o" name="numbermode_o">
          <input type="hidden" id="edit_db" name="edit_db">
          <input type="hidden" id="pid" name="pid">
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">บันทึก</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">ยกเลิก</button>
        </div>
      </div>
    </form>
  </div>

