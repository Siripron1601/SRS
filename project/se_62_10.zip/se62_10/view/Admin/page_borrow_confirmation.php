<?php 
session_start(); 
// ข้อมูลของคนที่เข้ามา

// try {
//   if (!isset($_SESSION['login'])) {
//     header("Location: ../../index.php?error=เกินข้อผิดพราด!");
// }
// }
// catch(Exception $e) {
//   echo "Access denied: No Permission to view this page";
//   exit(1);
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "link.php"?>
  <?php include "../../query.php"?>
<title>ระบบยืมของภาควิชาคอม</title>
</head>

<body id="page-top">
  <div id="wrapper" >

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
      <?php include "logout1.php" ?>
      
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content" >

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
        
        <div class="row">
          <div class="col-xl-12 col-12 mb-4">
            <div class="card">
                <div class="card-header card-bg">
                    หน้ายื่นยันการยืม
                    </div>
                </div>
          </div>
        </div>
              

       <form method="post" action="./page_mamage/basket_conf.php">
          <!-- เริ่ม -->
          <div class="row" >
                <!-- ส่วนของคำว่า "รายละเอียดรายการยืม" -->
                <div class="col-xl-12 col-12 mb-2"  >
                <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="h5 m-0 font-weight-bold text-primary">รายละเอียดรายการยืม </h6>
                  </div>
                  <div class="card-body" >
                    <div class="row mb-4">
                      <div class="col-xl-2 col-12 text-right">
                        <span>หมายเหตุ</span>
                      </div>
                      <div class="col-xl-9 col-12">
                      <textarea style="resize:none;" class="form-control rounded-0" id="Textnote" name="Textnote" rows="3"></textarea>
                      </div>
                  </div>
                </div>
                </div>
                <!-- จบ ส่วนของคำว่า "รายละเอียดรายการยืม" -->

                <!-- ส่วนของตาราง รายการขอยื่ม -->
                <div class="card shadow mb-1">
                <div class="card-header py-3">
                <h6 class="h5 m-0 font-weight-bold text-primary">รายการอุปกรณ์ที่จะยืม</h6>
                </div>
                <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-bordered"  width="100%" cellspacing="0">
                    <colgroup>
                      <col  width="20">
                      <col  width="20">
                      <col  width="20">
                      <col  width="20">
                      <col  width="20">
                      <col  width="20">
                      <col  width="20">
                    </colgroup>
                    <thead>
                      <tr>
                        <th>ภาพ</th>
                        <th>ชื่ออุปกรณ์</th>
                        <th>หมายหมู่</th>
                        <th>จำนวนที่เหลือ</th>
                        <th>รายละเอียด</th>
                        <th>จำนวนที่ขอยืม</th>
                        <th>จัดการ</th>
                      </tr>
                    </thead>
                    
                    <tbody>
                      <?php
                        foreach ($_SESSION['basket'] as $key => $val){?>
                          <?php
                          $stml = get_page_confirmation($val);
                          while($get_page_confirmation = $stml->fetch(PDO::FETCH_OBJ)){?>
                          <tr>
                            <td><img src="<?php echo $get_page_confirmation->picPath ?>" alt="Lights" style="width:100%;max-width:100px"></td>
                            <td><?php echo $get_page_confirmation->pName ?></td>
                            <td><?php echo $get_page_confirmation->cName ?></td>
                            <td><?php if($get_page_confirmation->countS!=null){echo $get_page_confirmation->countS ;}else{ echo '0';} ?></td>
                            <td><?php echo $get_page_confirmation->detail ?></td>
                            <td><input name="<?php echo "lend".$get_page_confirmation->pid ?>"  class="form-control form-control-user" type="number" min="0" max="<?php if($get_page_confirmation->countS!=null){echo $get_page_confirmation->countS ;}else{ echo '0';} ?>" value="0" ></td>
                            <td> <button type="button" onclick="delfunction('<?php echo $key ?>')" class="btn btn-danger btn-sm" data-toggle="tooltip" title="" data-original-title="ลบ" ><i class="far fa-trash-alt" aria-hidden="true"></i></button></td>
                          </tr>
                          <?php
                          }
                          ?>
                      <?php
                        }
                      ?>
                    </tbody>
                  </table>
                  
                </div>
                <div class="modal-footer">
                  <a><button type="submit" class="btn btn-success" name="submit">ยืนยัน</button></a>
                  <a href="./page_borrow.php" ><button type="button" class="btn btn-danger">ยกเลิก</button></a>
                </div>
                </div>
                </div>
                <!-- จบ ส่วนของตาราง รายการรออนุมัติ-->


                </div>
                <!-- จบ -->

       </form>

         
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 
 
</body>

</html>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>
<script>
   //  ฟังก์ชันลบ
   function delfunction(key) {

swal({
        title: "คุณแน่ใจหรือไม่?",
        text: key,
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        cancelButtonClass: "btn-secondary",
        confirmButtonText: "ยืนยัน",
        cancelButtonText: "ยกเลิก",
        closeOnConfirm: false,
        closeOnCancel: true
    },
    function(isConfirm) {
        if (isConfirm) {
            swal({
                title: "ลบเรียบร้อยแล้ว",
                type: "success",
                confirmButtonClass: "btn-danger",
                confirmButtonText: "ตกลง",
                closeOnConfirm: false,
            });
            delete_1(key);
            setTimeout(function() {
              location.reload();
            }, 1000);
        } else {
          
        }
    });
}
function delete_1(key) {
    $.ajax({
      type: "POST",
      data: {
        key: key,
        delete: "delete"
      },
      url: "./page_mamage/mamage_conf.php",
      async: false,
      success: function(result) {}
    });
  }
//  ฟังก์ชันลบ
</script>