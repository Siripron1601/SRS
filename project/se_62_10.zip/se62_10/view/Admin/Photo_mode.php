<style>
    .text-primary2 {
        color: #ffffff !important;
    }
</style>
<div id="deleteproduct" class="modal fade">
    <form class="imgForm" action="leanform.php" method="post" enctype="multipart/form-data">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header header-modal" style="background-color: #FF3366;">
                    <h4 class="m-0 font-weight-bold text-primary2">เพิ่มรูปภาพ</h4>
                </div>
                <div class="modal-body" id="passModalBody">
                    <div class="row" >
                        <div  class="col-12 text-center">
                            <img id="uploadPreview" src="./img_product/Add_Image.png" alt="Lights" style="width:300px;max-width:400px;" >
                        </div>
                    </div>
                    <br>
                    <div class="row mb-4">
                        
                        <div class="col-12 text-center">
                            <input id="uploadImage" type="file" name="myPhoto" onchange="PreviewImage();"  />
                        </div>
                        <input type="hidden" id="delete_id" name="delete_id"></input>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" id="edit_pass" name="edit_pass" class="btn btn-success">ยื่นยัง</button>
                    <button type="button" id="edit_cancel" name="edit_cancel" class="btn btn-danger" data-dismiss="modal">ยกเลิก</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">

    function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };

</script>