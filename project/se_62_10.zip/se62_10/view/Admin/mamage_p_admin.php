<?php
include_once("../../query.php");

echo $_POST['type'];
if($_POST['type'] == 'success'){
    up_log_order($_POST['log_id']);
    header("Location: Admin.php");
}
if($_POST['type'] == 'danger'){
    up_log_order_danger($_POST['log_id_danger']);
    header("Location: Admin.php");
}

?>