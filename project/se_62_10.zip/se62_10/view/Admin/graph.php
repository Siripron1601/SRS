<?php

$Y1 = $_GET['Y1'] ?? "";
$Y2 = $_GET['Y2'] ?? "";

$stml = graph_shows($Y1);
while ($graph_shows = $stml->fetch(PDO::FETCH_OBJ)){
    $pName = $graph_shows->pName;
    $COUNTID = $graph_shows->COUNTID;
    $X = $X."['$pName', $COUNTID],";
}  
?>
 <?php $dataArray1 = "["." ['ชื่ออุปกรณ์', 'จำนวนอุปกรณ์'],".$X."]" ; ?>

 <?php
 $stml = graph_shows_2($Y2);
 while ($graph_shows = $stml->fetch(PDO::FETCH_OBJ)){
     $Name = $graph_shows->firstname." ".$graph_shows->lastname;
     $COUNTID = $graph_shows->COUNTID;
     $X2 = $X2."['$Name', $COUNTID],";
 }  
 ?>
  <?php $dataArray2 = "["." ['ชื่ออาจารย์', 'จำนวนอนุมัติ'],".$X2."]" ; ?>
 
 


<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>   
<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript">
google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawChart2);
function drawChart2() {
    // สร้างตัวแปร array เก็บค่า ข้อมูล
    var dataArray1=<?=$dataArray1?>;
         
    // แปลงข้อมูลจาก array สำหรับใช้ในการสร้าง กราฟ
    var data = google.visualization.arrayToDataTable(dataArray1);
 
    // ตั้งค่าต่างๆ ของกราฟ
    var options = { 
        title: "กราฟแสดงจำนวนอุปกรณ์ที่ถูกยืม",
        hAxis: {title: 'ชื่ออุปกรณ์', titleTextStyle: {color: 'red'}},
        vAxis: {title: 'จำนวนอุปกรณ์', titleTextStyle: {color: 'blue'}},
        width: 1000,
        height: 400,
        bar: {groupWidth: "70%"},
        legend: { position: 'right', maxLines: 3 },
        tooltip: { trigger: 'select' }
    };
 
    // สร้างกราฟแนวตั้ง แสดงใน div id = chart_div
    var chart = new google.visualization.ColumnChart(document.getElementById('chart_div2'));
    chart.draw(data, options); // สร้างกราฟ
     
}
</script>       







<script type="text/javascript">
google.load("visualization", "1", {packages:["corechart"]});
google.setOnLoadCallback(drawChart1);
function drawChart1() {
    // สร้างตัวแปร array เก็บค่า ข้อมูล
    var dataArray2=<?=$dataArray2?>;
         
    // แปลงข้อมูลจาก array สำหรับใช้ในการสร้าง กราฟ
    var data = google.visualization.arrayToDataTable(dataArray2);
 
    // ตั้งค่าต่างๆ ของกราฟ
    var options = { 
        title: "กราฟแสดงจำนวนอุปกรณ์ที่ถูกยืม",
        hAxis: {title: 'ชื่ออาจารย์', titleTextStyle: {color: 'red'}},
        vAxis: {title: 'จำนวนอนุมัติ', titleTextStyle: {color: 'blue'}},
        width: 1000,
        height: 400,
        bar: {groupWidth: "70%"},
        legend: { position: 'right', maxLines: 3 },
        tooltip: { trigger: 'select' }
    };
 
    // สร้างกราฟแนวตั้ง แสดงใน div id = chart_div
    var chart = new google.visualization.ColumnChart(document.getElementById('chart_div1'));
    chart.draw(data, options); // สร้างกราฟ
     
}
</script>       
