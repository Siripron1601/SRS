<?php 
session_start(); 
// ข้อมูลของคนที่เข้ามา

// try {
//   if (!isset($_SESSION['login'])) {
//     header("Location: ../../index.php?error=เกินข้อผิดพราด!");
// }
// }
// catch(Exception $e) {
//   echo "Access denied: No Permission to view this page";
//   exit(1);
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "link.php" ;?>
  <?php include "../../query.php" ;?>
  <?php include "Admin_mode_order.php" ;?>
  <?php include "Admin_mode_success.php" ;?>
  <?php include "Admin_mode_danger.php" ;?>
  <?php
  // เป็นช่องดึงค่าจาก DB
    $stml = get_count_order();
    while ($get_count_order = $stml->fetch(PDO::FETCH_OBJ)){
      $COUNT_ORDER =  $get_count_order->COUNT_ORDER;
    } 
  ?>
<script>
    function showHint(str) {
        $("#detailorder").modal('show');
        $('#order_id').val(str);
        if (str.length == 0) {
            document.getElementById("txtHint").innerHTML = "";
            return;
        } else {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("txtHint").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "gethint.php?q=" + str, true);
            xmlhttp.send();
        }
    }
</script>
  <title>ระบบยืมของภาควิชาคอม</title>
</head>

<body id="page-top">
  <div id="wrapper" >

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
      <?php include "logout1.php" ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content" >

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

           

        <!-- เริ่ม -->
            <div class="row" >

                  <!-- ส่วนของคำว่า "หน้าหลัก" -->
                <div class="col-xl-12 col-12 mb-4"  >
                    <div class="card" >
                        <div class="card-header card-bg  header-text-color"  style="background-color:#fff;">
                        หน้าหลัก
                        </div>
                        
                        
                    </div>
                </div>
                  <!-- จบ ส่วนของคำว่า "หน้าหลัก" -->
                  
                  <!-- เริ่มส่วนของ card-->

                    <!--  card คำขอที่รอการอนุมัติ -->
                    <div class="col-xl-3 col-md-6 mb-4">
                      <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                          <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                              <div class=" h6 font-weight-bold text-primary  mb-1">จำนวนที่อนุมัติแล้ว</div>
                              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $COUNT_ORDER; ?> คำขอ</div>
                            </div>
                            <div class="col-auto">
                              <i class="fas fa-mail-bulk fa-2x "></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    
              <!-- จบส่วนของ card-->
                 
              
            </div>
        <!-- จบ -->
  

         <!-- ส่วนของตาราง รายการขอยื่ม -->
         <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="h5 m-0 font-weight-bold text-primary">รายการที่ผ่านการอนุมัติ </h6>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <colgroup>
                        <col  width="20">
                        <col  width="100">
                        <col  width="20">
                        <col  width="20">
                        <col  width="150">
                        <col  width="150">
                        <col  width="100">
                        <col  width="20">
                      </colgroup>
                      <thead>
                        <tr>
                          <th>รายการ</th>
                          <th>วันที่</th>
                          <th>รหัส</th>
                          <th>สถานะ</th>
                          <th>ชื่อ - นามสกุล</th>
                          <th>อาจารย์ที่อนุมัติ</th>
                          <th>รายละเอียดอุปกรณ์</th>
                          <th>จัดการ</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <th>รายการ</th>
                          <th>วันที่</th>
                          <th>รหัส</th>
                          <th>สถานะ</th>
                          <th>ชื่อ - นามสกุล</th>
                          <th>อาจารย์ที่อนุมัติ</th>
                          <th>รายละเอียด อุปกรณ์</th>
                          <th>จัดการ</th>
                        </tr>
                      </tfoot>
                      <tbody>

                        <?php
                         $stml = get_P_admin();
                        $h = 4; //จำนวนหลัก
                        while ($get_P_admin = $stml->fetch(PDO::FETCH_OBJ)){?>
                          <tr>
                            <td><?php $id = $get_P_admin->log_id;  echo "A", sprintf("%0" . $h . "d", $id);  $id = "A". sprintf("%0" . $h . "d", $id);?></td>
                            <td><?php echo $get_P_admin->date  ?></td>
                            <td><?php echo $get_P_admin->stCode  ?></td></td>
                            <td>
                              <?php  
                                if($get_P_admin->status_user == 1){
                                  echo "อาจารย์";
                                }elseif($get_P_admin->status_user == 2){
                                  echo "เจ้าหน้าที่";
                                }else{
                                  echo "นิสิต";
                                }
                              ?>
                            </td>
                            <td><?php echo $get_P_admin->title_user." ".$get_P_admin->firstname_user." ".$get_P_admin->lastname_user ; $name = $get_P_admin->title_user." ".$get_P_admin->firstname_user." ".$get_P_admin->lastname_user ; ?></td>
                            <td><?php if($get_P_admin->title=="") echo "-" ; else echo $get_P_admin->title." ".$get_P_admin->firstname." ".$get_P_admin->lastname   ?> </td>
                            <td style="text-align:center;"><button  type="button" class="btn btn-warning  btn-sm" data-toggle="tooltip" title="" data-original-title="รายละเอียด" onclick="deleteProduct(<?php echo $get_P_admin->log_id ?>)"><?php echo "จำนวนอุปกรณ์  ".$get_P_admin->countP ?></button></td>
                            <td style="text-align:center;">
                                <button type="button" class="btn btn-success btn-sm" data-toggle="tooltip" title="" data-original-title="ยืนยัน" onclick="successmode('<?php echo $id;?>','<?php echo $get_P_admin->log_id;?>','<?php echo $get_P_admin->date;?>','<?php echo $get_P_admin->stCode;?>','<?php echo $name;?>')"><i class="fa fa-check" aria-hidden="true"></i></button>
                                <button type="button" class="btn btn-danger btn-sm" data-toggle="tooltip" title="" data-original-title="ยกเลิก" onclick="dangermode('<?php echo $id;?>','<?php echo $get_P_admin->log_id;?>','<?php echo $get_P_admin->date;?>','<?php echo $get_P_admin->stCode;?>','<?php echo $name;?>')"><i class="fa fa-times" aria-hidden="true"></i></button>
                            </td>
                         </tr>

                        <?php
                        } 
                        ?>
                        <!-- <tr>
                          <td>1</td>
                          <td>28-02-63</td>
                          <td>A001</td></td>
                          <td>นางสาวจินต์จุฑา วรโคตร</td>
                          <td>อ.นุชนาฎ  สัตยากวี</td>
                          <td>3</td>
                          <td style="text-align:center;">
                              <button type="button" class="btn btn-success btn-sm" data-toggle="tooltip" title="" data-original-title="ยืนยัน"><i class="fa fa-check" aria-hidden="true"></i></button>
                              <button type="button" class="btn btn-danger btn-sm" data-toggle="tooltip" title="" data-original-title="ยกเลิก" ><i class="fa fa-times" aria-hidden="true"></i></button>
                          </td>
                        </tr> -->
                       
                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
        <!-- จบ ส่วนของตาราง รายการรออนุมัติ-->
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 
 
</body>

</html>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});

function successmode($id,$log_id,$data,$stCode,$name) {
    $("#success").modal('show');
    $('#id').val($id);
    $('#log_id').val($log_id);
    $('#data').val($data);
    $('#stCode').val($stCode);
    $('#name').val($name);
  }
  function dangermode($id,$log_id,$data,$stCode,$name) {
    $("#danger").modal('show');
    $('#id_danger').val($id);
    $('#log_id_danger').val($log_id);
    $('#data_danger').val($data);
    $('#stCode_danger').val($stCode);
    $('#name_danger').val($name);
  }




</script>