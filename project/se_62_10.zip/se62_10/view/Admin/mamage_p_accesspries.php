<?php
session_start(); 
include "../../query.php";


if(isset($_POST['delete'])){
    del_db_product($_POST['id1']);
}
if(isset($_POST['lock'])){
    up_lock_db_product($_POST['id1']);
}
if(isset($_POST['openlock'])){
    up_openlock_db_product($_POST['id1']);
}



?>