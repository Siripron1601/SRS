<?php 
    session_start();
    $hidden = $_POST['hidden'];
    if(isset($_SESSION['array'])){
        $array = $_SESSION['array'];
        $array_lock = $_SESSION['array'];
    }
    else{
        $array=[];
        $array_lock=[];
    }
    
	for($i=1;$i<=$hidden;$i++){
		$tel[$i] = $_POST['tel'.$i];
        echo "phone$i = "; echo $tel[$i]; echo "<br>";
        $array[$tel[$i]] = $tel[$i];
        $array_lock[$tel[$i]] = 0;
    }
    $_SESSION['array'] = $array ;
    $_SESSION['array_lock'] = $array_lock ;
    header("Location: Admin_add_accessories.php");

?>