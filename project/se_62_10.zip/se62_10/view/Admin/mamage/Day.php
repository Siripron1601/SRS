<?php
include "../../../query.php";
up_day($_POST['firstname']);
header("location:../Pick_up_date.php");
?>