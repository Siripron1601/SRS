<?php
include "../../../query.php";

if(isset($_POST['success'])){
    $log_id =  $_POST['log_id'];
    up_waitback_Admin($_POST['suggestion'],$_POST['log_id']);
    header("location:../Admin_waitback.php");
}

?>