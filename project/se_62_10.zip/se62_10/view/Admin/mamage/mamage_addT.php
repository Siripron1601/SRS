<?php
    include "../../../query.php";
    if(isset($_POST['addTea']))
    {
        $formalId = $_POST['formalId'];
        $title = $_POST['title'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        add_db_teache($formalId,$title,$firstname,$lastname,$email);
        header("location:../Admin_add_T.php");
    }
    
    if(isset($_POST['delete'])){
        del_db_t($_POST['id1']);
    }


?>