<style>
    .text-primary2 {
        color: #ffffff !important;
    }
    .modal-content2 {
        position: relative;
        display: flex;
        flex-direction: column;
        width: 100%;
        pointer-events: auto;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid rgba(0, 0, 0, 0.2);
        border-radius: 0.3rem;
        outline: 0;
    }
</style>
<script>
    function deleteProduct(str) {
    $("#deleteproduct").modal('show');
    $('#order_id').val(str);
        if (str.length == 0) {
            document.getElementById("txtHint").innerHTML = "";
            return;
        } else {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("txtHint").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "Admin_t.php?q=" + str, true);
            xmlhttp.send();
        }
  }
</script>
<script>
	$(document).ready(function(){
		first();                   // เมื่อ page ถูกโหลดจะทำฟังก์ชัน first ก่อน
		$('#btnAdd').click(first); // เมื่อ click จะสร้าง element ขึ้นมาใหม่(สร้างอินพุตใหม่)
		$('#btnSend').click(send); //เมื่อคลิกจะทำฟังก์ชัน send
	});
	
	function first(){
		var id = $('#cover div').length+1;            // นับว่ามี tag div กี่อันแล้ว แล้ว +1
		var wrapper = $("<br><div class='col-12 text-center' id=\"field"+id+"\">");  // สร้าง div
		var parag   = $("<p>เลขครุภัณฑ์ : \""+id+"\"</p>");   // สร้าง p
		var text    = $("<input class='form-control' type='text' name=\"tel"+id+"\" />"); // สร้าง input
		var btnDel  = $("<br><input class='btn btn-danger btn-sm' type='button' value='ลบ' id=\"btn"+id+"\"/>"); 
		btnDel.click(function(){
			$(this).parent().remove();			
		});
		
		wrapper.append(parag);   
		wrapper.append(text);
		wrapper.append(btnDel);
		$('#cover').append(wrapper);
	}
	
	function send(){  //นับ div ทั้งหมดก่อนส่ง
		var id= $('#cover div').length;
		var hiddens = $("<input type='hidden' name='hidden' value=\""+id+"\"/>");
		$('form').append(hiddens);
		$('form').submit(); 
	}
</script>
    <div id="numbermode" class="modal fade">
    <form class="modal-dialog modal-lg " method="post" id="formEdit" name="formEdit" action="receive_ed.php">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content2" >
                <div class="modal-header header-modal" style="background-color: #42b9d6;">
                
                    <h4 class="m-0 font-weight-bold text-primary2">เพิ่มเลขครุภัณฑ์</h4>
                    <button id="btnAdd" value="add" type="button"  style="float:right;" class="btn btn-success" data-toggle="modal" data-target="#modal-1" onclick="number()">เพื่มเลขครุภัณฑ์</button>
                </div>
                <div class="modal-body" id="passModalBody">
                    <div id="cover"> 
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="pid_db_2" name="pid_db_2">
                    <input type="submit" id="btnSend" class="btn btn-success" value="ยืนยัง"/>
                    <button type="button" id="edit_pass" name="edit_pass" class="btn btn-danger " data-dismiss="modal">ปิด</button>
                </div>
            </div>
        </div>
        
    </form>
</div>

