<div id="numbermode_ed_db" class="modal fade">
    <form class="modal-dialog modal-lg " method="POST" action='mamage_p_add_2.php'>
      <div class="modal-content">
        <div class="modal-header" style="background-color:#eecc0b"><h4 class="modal-title" style="color:white">อออออแก้ไขเลขครุภัณฑ์ </h4></div>
        <div class="modal-body" id="AddModalBody">
            <div class="row mb-4"><div class="col-xl-3 col-12 text-right">
              <span>เลขครุภัณฑ์ :</span>
            </div>
            <div class="col-xl-8 col-12">
              <input type="text" class="form-control" id="serialNum" name="serialNum" value="" maxlength="100">
            </div>
          </div>
          <input type="hidden" id="edit_db_2" name="edit_db_2">
          
          <input type="hidden" id="pid_db" name="pid_db">
          <input type="hidden" id="sid" name="sid">
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">บันทึก</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">ยกเลิก</button>
        </div>
      </div>
    </form>
  </div>

