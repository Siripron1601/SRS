<?php
 session_start();
if($_POST){
    if(isset($_FILES['upload'])){
        $name_file =  $_FILES['upload']['name'];
        $tmp_name =  $_FILES['upload']['tmp_name'];
        $locate_img ="img_product/";
        move_uploaded_file($tmp_name,$locate_img.$name_file);
        $locate_img2 ="../Teacher/img_product";
        move_uploaded_file($tmp_name,$locate_img2.$name_file);
        $locate_img3 ="../User/img_product/";
        move_uploaded_file($tmp_name,$locate_img3.$name_file);
        header("Location: Admin_add_accessories.php");
        $_SESSION['jpg'] = $name_file;
    }
}
?>
