<?php
session_start();
$DATAUSER = $_SESSION['DATAUSER'] ?? NULL;
require_once('../../view/Admin/link.php');
include("../../dbConnect.php");
$sqlHisAd = "SELECT *
FROM log_order INNER JOIN log_detailborrow ON log_order.log_id = log_detailborrow.log_orderid 
INNER JOIN dim_product ON log_detailborrow.dim_product = dim_product.dimProduct
INNER JOIN dim_user ON dim_user.dim_id = log_order.dim_uid 
INNER JOIN dim_teacher ON log_order.dim_tid = dim_teacher.dim_id 
WHERE dim_user.status = '3' AND log_order.status_borrow != '1' ";

$TableAdmin = selectData($sqlHisAd);

// $sqldbProduct = "SELECT * FROM `db_product` WHERE 1";

// $TabledbProduct = selectData($sqldbProduct);

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "link.php" ?>
  <title>ระบบยืมของภาควิชาคอม</title>
</head>

<body id="page-top">
  <div id="wrapper">

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
    <?php include "logout1.php" ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content">

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">



          <!-- เริ่ม -->
          <div class="row">

            <!-- ส่วนของคำว่า "หน้าหลัก" -->
            <div class="col-xl-12 col-12 mb-4">
              <div class="card">
                <div class="card-header card-bg  header-text-color" style="background-color:#fff;">
                  หน้าประวัติการยืม - คืนอุปกรณ์ของผู้ยืม

                </div>


              </div>
            </div>
            <!-- จบ ส่วนของคำว่า "หน้าหลัก" -->




          </div>
          <!-- จบ -->


          <!-- ส่วนของตาราง รายการขอยื่ม -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="h5 m-0 font-weight-bold text-primary">ประวัติการยืม - คืนอุปกรณ์ของผู้ยืมทั้งหมด</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <colgroup>
                    <col width="20">
                    <col width="20">
                    <col width="20">
                    <col width="20">
                    <col width="20">
                    <col width="20">
                    <col width="20">
                    <col width="20">
                    <col width="40">
                  </colgroup>
                  <thead>
                    <tr>
                      <th>รหัสรายการ</th>
                      <th>วันที่ยืม</th>
                      <th>วันที่คืน</th>
                      <th>รหัสประจำตัว</th>
                      <th>ชื่อ - นามสกุล</th>
                      <th>จำนวนอุปกรณ์</th>
                      <th>ผู้อนุมัติ</th>
                      <th>หมายเหตุ</th>
                      <th>สถานะ</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>รหัสรายการ</th>
                      <th>วันที่ยืม</th>
                      <th>วันที่คืน</th>
                      <th>รหัสประจำตัว</th>
                      <th>ชื่อ - นามสกุล</th>
                      <th>จำนวนอุปกรณ์</th>
                      <th>ผู้อนุมัติ</th>
                      <th>หมายเหตุ</th>
                      <th>สถานะ</th>
                    </tr>
                  </tfoot>
                  <tbody>
                    <?php for ($i = 0; $i < $TableAdmin[0]['numrow']; $i++) {
                      $item = $i + 1; ?>

                      <tr role="row" class="odd" style="text-align:center;">
                        <td class="sorting_1">
                          <div align="center"><?= $item ?></div>
                        </td>
                        <td><?php echo $TableAdmin[$i + 1]['date'] ?></td>
                        <td><?php echo $TableAdmin[$i + 1]['date_Pick_up'] ?></td>
                        <td><?php echo $TableAdmin[$i + 1]['stCode'] ?></td>
                        <td><?php echo $TableAdmin[$i + 1]['title'] ?>
                          <?php echo $TableAdmin[$i + 1]['firstname'] ?>
                          <?php echo $TableAdmin[$i + 1]['lastname'] ?></td>
                        <td style="text-align:center;">
                          <a href="#" class="detailTool">
                            <button type="button" class="btn btn-warning btn-sm tt" title='รายละเอียด'>
                              <span>จำนวนอุปกรณ์ <?php echo $TableAdmin[$i + 1]['borrowNum'] ?></span>
                            </button>
                          </a>
                        </td>
                        <td><?php echo $TableAdmin[$i + 1]['title'] ?>
                          <?php echo $TableAdmin[$i + 1]['firstname'] ?>
                          <?php echo $TableAdmin[$i + 1]['lastname'] ?></td>
                        <td><?php echo $TableAdmin[$i + 1]['confirm_note'] ?></td>
                        <td><?php echo $TableAdmin[$i + 1]['return_note'] ?></td>

                      </tr>
                    <?php } ?>

                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- จบ ส่วนของตาราง รายการรออนุมัติ-->
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>



</body>

<div>
  <div id="modalDetail" class="modal fade">
    <form class="modal-dialog modal-lg" method="POST" action='manage.php'>
      <div class="modal-content">
        <div class="modal-header" style="background-color:#eecc0b">
          <h4 class="modal-title" style="color:white">รายละเอียดอุปกรณ์</h4>
        </div>
        <div class="modal-body" id="addModalBody">
          <div class="row mb-4">
            <div class="col-sm-12">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr role="row">
                    <th rowspan="1" colspan="1">ลำดับ</th>
                    <th rowspan="1" colspan="1">เลขครุภัณฑ์</th>
                    <th rowspan="1" colspan="1">ชื่ออุปกรณ์</th>

                  </tr>
                </thead>
                <tbody>
                  <?php
                  for ($i = 0; $i < $TableAdmin[0]['numrow']; $i++) {
                    $item = $i + 1;
                  ?>
                    <tr role="row" class="odd" style="text-align:center;">
                      <td class="sorting_1">


                        <div align="center"><?= $item ?></div>
                      </td>
                      <td>
                        <?php echo $TableAdmin[$i + 1]['serialNum'] ?></td>
                      <td>
                        <?php echo $TableAdmin[$i + 1]['pName'] ?></td>

                    </tr>
                  <?php }
                  ?>

                </tbody>
              </table>

            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>

</html>
<script>
  $(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();
  });

  $(document).ready(function() {
    console.log("ready!");
    $('.tt').tooltip({
      trigger: "hover"
    });
  });
  $(".detailTool").click(function() {


    // var detail = $(this).attr('pName');
    // alert(pName)

    // $('#pName').val(detail);

    $("#modalDetail").modal('show');
  });
</script>