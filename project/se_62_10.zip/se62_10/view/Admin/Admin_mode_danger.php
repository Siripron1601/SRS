<div id="danger" class="modal fade">
    <form method="post" id="danger" name="formEdit" action="mamage_p_admin.php">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content2" >
                <div class="modal-header header-modal" style="background-color: #ff0000;">
                    <h4 class="m-0 font-weight-bold text-primary2">ยกเลิกการมารับอุปกรณ์</h4>
                </div>
                <div class="modal-body" id="passModalBody_danger">
                    <div class="row mb-4">
                        
                        <table class="table table-bordered" width="100%" cellspacing="0">
                            <colgroup>
                                <col  width="20">
                                <col  width="20">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th style="text-align:center;"><h5 class="m-0 font-weight-bold text-primary">รหัสรายการ</h5></th>
                                    <th style="text-align:center;"><input type="text" class="form-control" id="id_danger" name="delete_id" value="144" disabled></input></th>
                                </tr>
                                <tr>
                                    <th style="text-align:center;"><h5 class="m-0 font-weight-bold text-primary">วันที่ผ่านการอนุมัติ</h5></th>
                                    <th style="text-align:center;"><input type="text" class="form-control" id="data_danger" name="delete_id" disabled></input></th>
                                </tr>
                                <tr>
                                    <th style="text-align:center;"><h5 class="m-0 font-weight-bold text-primary">รหัสประจำตัว</h5></th>
                                    <th style="text-align:center;"><input type="text" class="form-control" id="stCode_danger" name="delete_id" disabled></input></th>
                                </tr>
                                <tr>
                                    <th style="text-align:center;"><h5 class="m-0 font-weight-bold text-primary">ผู้ทำรายการ</h5></th>
                                    <th style="text-align:center;"><input type="text" class="form-control" id="name_danger" name="delete_id" disabled></input></th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                        <input type="hidden" id="log_id_danger" name="log_id_danger"></input>
                        <input type="hidden" id="type"  name="type" value="danger"></input>
                       
                    </div>
                   
                </div>
                <div class="modal-footer">
                        <button type="submit" id="edit_pass" name="edit_pass" class="btn btn-success" >ยืนยัง</button>
                        <button type="button" id="edit_pass" name="edit_pass" class="btn btn-danger "  data-dismiss="modal">ปิด</button>
                    </div>
            </div>
        </div>
    </form>
</div>
