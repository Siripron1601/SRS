<!DOCTYPE html>
<html lang="en">
<style>
.text-primary2 {
  color: #FF3366 !important;
}</style>

<head>
<?php session_start();?>
  <?php include "link.php"?>
  <?php require_once('query.php'); ?>
  <?php $year = $_GET['Y'] ?? "";?>
<title>ระบบยืมของภาควิชาคอม</title>
</head>

<body id="page-top">
  <div id="wrapper" >

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
    <?php include "layout_admin.php"?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content" >

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

           

        <!-- เริ่ม -->
            <div class="row" >

            </div>
        <!-- จบ -->
       
          

           <!-- ส่วนของตาราง รายการขอยื่ม -->
         <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="h5 m-0 font-weight-bold text-primary2" >Sales Statistics Graph</h6>
                    <p id="demo"></p>
                  <div class="col-3">
                  Choose display result(Year)
                    <select class="form-control" id="cars" onchange="myFunction()"  >
                      <option value="" >Every year</option>
                        <?php
                            $stmt = get_Year();
                            while ($get_Year = $stmt->fetch(PDO::FETCH_OBJ)) {?>
                                        <option value="<?php echo $get_Year->d_year ?>" <?php if($get_Year->d_year == $year){echo "selected";}  ?> ><?php echo $get_Year->d_year ?></option>
                            <?php
                            }
                        ?>
                    </select>
                    
                  </div>
                </div>
                
                <!-- <iframe   src="./P25.php"  height="500" width="100%" style="border:none;"></iframe> -->
                <?php include "./graph.php" ;?>
                
     
        </div>
     
        </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 
 
</body>

</html>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<script>
function get_Year(){
    header("Location: cart.php");
}

</script>
<script>
function myFunction() {
  var x = document.getElementById("cars").value;
  location.href = "./Statistics.php?Y="+x+"";
  
}
</script>