<?php 
session_start(); 
// ข้อมูลของคนที่เข้ามา

// try {
//   if (!isset($_SESSION['login'])) {
//     header("Location: ../../index.php?error=เกินข้อผิดพราด!");
// }
// }
// catch(Exception $e) {
//   echo "Access denied: No Permission to view this page";
//   exit(1);
// }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "link.php"?>
  <?php include "../../query.php"?>
  <?php
  // เป็นช่องดึงค่าจาก DB
    $COUNT_T = get_T();
  ?>
<title>ระบบยืมของภาควิชาคอม</title>
</head>

<body id="page-top">
  <div id="wrapper" >

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
      <?php include "logout1.php" ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content" >

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

           

        <!-- เริ่ม -->
            <div class="row" >

                  <!-- ส่วนของคำว่า "หน้าหลัก" -->
                <div class="col-xl-12 col-12 mb-4"  >
                    <div class="card" >
                        <div class="card-header card-bg  header-text-color"  style="background-color:#fff;">
                        หน้ารายชื่ออาจารย์
                        </div>
                        
                        
                    </div>
                </div>
                  <!-- จบ ส่วนของคำว่า "หน้าหลัก" -->
                  
                  <!-- เริ่มส่วนของ card-->

                     <!--  card คำขอที่อนุมัติแล้ว -->
                     <div class="col-xl-3 col-md-6 mb-4">
                      <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                          <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                              <div class=" h6 font-weight-bold text-primary  mb-1">จำนวนรายชื่ออาจารย์</div>
                              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $COUNT_T;?> คน</div>
                            </div>
                            <div class="col-auto">
                              <i class="fas fa-mail-bulk fa-2x "></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!--  card คำขอที่อนุมัติแล้ว -->
                    <div class="col-xl-3 col-md-6 mb-4">
                            <a href="#" style="text-decoration: none">
                                <div class="card border-left-info shadow h-100 py-2" id="addTeacher">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                            <div class="col mr-2">
                                                <div class=" h6 font-weight-bold text-info  mb-1">เพิ่มรายชื่ออาจารย์</div>
                                                <div class="h5 mb-0 font-weight-bold text-gray-800">+ อาจารย์</div>
                                            </div>
                                            <div class="col-auto text-info">
                                                <i class="fas fa-plus-circle fa-3x"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </a>
                    
              <!-- จบส่วนของ card-->
                 
              
            </div>
        <!-- จบ -->
         <!-- ส่วนของตาราง รายการขอยื่ม -->
         <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="h5 m-0 font-weight-bold text-primary">รายชื่ออาจารย์ที่มีสิทธิ์ในการอนุมัติ</h6>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <colgroup>
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                      </colgroup>
                      <thead>
                        <tr>
                            <th>ลำดับ</th>
                            <th>รหัสประจำตัว</th>
                            <th>ชื่อ - นามสกุล</th>
                            <th>จัดการ</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                            <th>ลำดับ</th>
                            <th>รหัสประจำตัว</th>
                            <th>ชื่อ - นามสกุล</th>
                            <th>จัดการ</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        <?php
                          $stml = get_All_t();
                          $i =1;
                         while ($get_all_t = $stml->fetch(PDO::FETCH_OBJ)){?>
                         <tr>
                          <td><?php echo $i ;?></td>
                          <td><?php echo $get_all_t->formalId ;?></td>
                          <td><?php echo $get_all_t->title." ".$get_all_t->firstname." ".$get_all_t->lastname ;?></td>
                          <td style="text-align:center;">
                              <button type="button" class="btn btn-danger btn-sm" data-toggle="tooltip" title="" data-original-title="ลบ" onclick="delfunction('<?php echo $get_all_t->title.' '.$get_all_t->firstname.' '.$get_all_t->lastname ?>','<?php echo $get_all_t->tid ?>')" ><i class="far fa-trash-alt" aria-hidden="true"></i></button>
                          </td>
                        </tr>
                        <?php
                        }  
                        ?>
                     <!-- fas fa-lock-open fas fa-lock-->
                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
        <!-- จบ ส่วนของตาราง รายการรออนุมัติ-->
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <div id="modalAddTeacher" class="modal fade">
        <form class="modal-dialog modal-lg " method="POST" action="./mamage/mamage_addT.php">
            <div class="modal-content">
                <div class="modal-header" style="background-color:#3E49BB">
                    <h4 class="modal-title" style="color:white">เพิ่มรายชื่ออาจารย์</h4>
                </div>
                <div class="modal-body">

                    <div class="row mb-4">
                        <div class="col-xl-3 col-12 text-right">
                            <span>รหัสประจำตัว :</span>
                        </div>
                        <div class="col-xl-8 col-12">
                            <input type="text" class="form-control" id="formalId" name="formalId" value="" placeholder="กรุณากรอกรหัส" maxlength="100">
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-xl-3 col-12 text-right">
                            <span>คำนำหน้า :</span>
                        </div>
                        <div class="col-lg-auto col-md-9 col-sm-6 col-xs-6">
                            <select class="custom-select  mb-3" id="title" name="title">
                                <option>นาย</option>
                                <option>นาง</option>
                                <option>นางสาว</option>
                            </select> </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-xl-3 col-12 text-right">
                            <span>ชื่อ :</span>
                        </div>
                        <div class="col-xl-8 col-12">
                            <input type="text" class="form-control" id="firstname" name="firstname" value="" placeholder="กรุณากรอกชื่อ" maxlength="100">
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-xl-3 col-12 text-right">
                            <span>นามสกุล :</span>
                        </div>
                        <div class="col-xl-8 col-12">
                            <input type="text" class="form-control" id="lastname" name="lastname" value="" placeholder="กรุณากรอกนามสกุล" maxlength="100">
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-xl-3 col-12 text-right">
                            <span>Email :</span>
                        </div>
                        <div class="col-xl-8 col-12">
                            <input type="text" class="form-control" id="email" name="email" value="" placeholder="กรุณากรอก email" maxlength="100">
                        </div>
                    </div>
                    <input type="hidden" name="addTea">


                </div>
                <div class="modal-footer">
                    <button class="btn btn-success" type="submit">บันทึก</button>
                    <button type="button" class="btn btn-danger" data-dismiss="modal">ยกเลิก</button>
                </div>
            </div>
        </form>
    </div>
 
</body>

</html>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});

$(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();

            $("#addTeacher").on('click', function() {

                $("#modalAddTeacher").modal('show');
            });
        });

</script>

<script>
 

  //  ฟังก์ชันลบ
  function delfunction(name,id) {
  swal({
          title: "คุณแน่ใจหรือไม่?",
          text: "คุณต้องการลบ "+name,
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          cancelButtonClass: "btn-secondary",
          confirmButtonText: "ยืนยัน",
          cancelButtonText: "ยกเลิก",
          closeOnConfirm: false,
          closeOnCancel: true
      },
      function(isConfirm) {
          if (isConfirm) {
              swal({
                  title: "ลบเรียบร้อยแล้ว",
                  type: "success",
                  confirmButtonClass: "btn-danger",
                  confirmButtonText: "ตกลง",
                  closeOnConfirm: false,
              });
              delete_1(id);
              setTimeout(function() {
                location.reload();
              }, 1000);
          } else {

          }
      });
  }
  function delete_1(id1) {
      $.ajax({
        type: "POST",
        data: {
          id1: id1,
          delete: "delete"
        },
        url: "./mamage/mamage_addT.php",
        async: false,
        success: function(result) {}
      });
    }
  //  ฟังก์ชันลบ


</script>