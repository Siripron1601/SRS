<?php
include_once("../../query.php");
// get the q parameter from URL
$q = $_REQUEST["q"];
$stml = get_lod_detailborrow($q);

// Output "no suggestion" if no hint was found or output correct values
?>
<br>
    <table class="table table-bordered" width="100%" cellspacing="0">
        <colgroup>
            <col  width="20">
            <col  width="20">
            <col  width="20">
            <col  width="20">
            <col  width="20">
            <col  width="20">
        </colgroup>
        <thead>
            <tr>
                <th>ลำดับ</th>
                <th>เลขครุภัณฑ์</th>
                <th>ชื่ออุปกรณ์</th>
                <th>จำนวน</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $i = 1;
            while ($get_lod_detailborrow = $stml->fetch(PDO::FETCH_OBJ)){?>
                <tr>
                <td><?php echo $i ;?></td>
                <td><?php echo $get_lod_detailborrow->serialNum;  ?></td>
                <td><?php echo $get_lod_detailborrow->pName;  ?></td>
                <td><?php echo $get_lod_detailborrow->borrowNum;  ?></td>
                </tr>
            <?php
            $i +=1;
            }
            ?> 
            <!-- <tr>
                <td>1</td>
                <td>28-02-63</td>
                <td>scsc</td>
                <td>นส.ป้อม</td>
            </tr> -->
        </tbody>
    </table>
