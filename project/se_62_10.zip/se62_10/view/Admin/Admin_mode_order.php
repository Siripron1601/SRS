
<style>
    .text-primary2 {
        color: #ffffff !important;
    }
    .modal-content2 {
        position: relative;
        display: flex;
        flex-direction: column;
        width: 100%;
        pointer-events: auto;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid rgba(0, 0, 0, 0.2);
        border-radius: 0.3rem;
        outline: 0;
    }
</style>
<script>
    function deleteProduct(str) {
    $("#deleteproduct").modal('show');
    $('#order_id').val(str);
        if (str.length == 0) {
            document.getElementById("txtHint").innerHTML = "";
            return;
        } else {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("txtHint").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "Admin_t.php?q=" + str, true);
            xmlhttp.send();
        }
  }
</script>
<div id="deleteproduct" class="modal fade">
    <form method="post" id="formEdit" name="formEdit" action="deleteproduct_DB.php">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content2" >
                <div class="modal-header header-modal" style="background-color: #42b9d6;">
                    <h4 class="m-0 font-weight-bold text-primary2">รายละเอียดอุปกรณ์ที่ทำรายการ</h4>
                </div>
                <div class="modal-body" id="passModalBody">
                    <div class="row mb-4">
                        <div class="col-12" style="background-color: #ffffff;">
                            <h6 class="h5 m-0 font-weight-bold text-primary">รายการอุปกรณ์ </h6>
                        </div>
                        <br>
                        <div id="txtHint" class="col-12 text-center">
                        </div>
                        <input type="hidden" id="delete_id" name="delete_id"></input>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="edit_pass" name="edit_pass" class="btn btn-success"  data-dismiss="modal">ปิด</button>
                   
                </div>
            </div>
        </div>
    </form>
</div>

