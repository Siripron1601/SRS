<?php 
session_start(); 
// ข้อมูลของคนที่เข้ามา

// try {
//   if (!isset($_SESSION['login'])) {
//     header("Location: ../../index.php?error=เกินข้อผิดพราด!");
// }
// }
// catch(Exception $e) {
//   echo "Access denied: No Permission to view this page";
//   exit(1);
// }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "link.php"?>
  <?php include "../../query.php"?>
  <?php
  // เป็นช่องดึงค่าจาก DB
    $stml = get_count_product();
    while ($get_count_product = $stml->fetch(PDO::FETCH_OBJ)){
      $COUNT_product =  $get_count_product->COUNT_product;
      
    } 
  ?>
<title>ระบบยืมของภาควิชาคอม</title>
</head>

<body id="page-top">
  <div id="wrapper" >

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
      <?php include "logout1.php" ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content" >

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

           

        <!-- เริ่ม -->
            <div class="row" >

                  <!-- ส่วนของคำว่า "หน้าหลัก" -->
                <div class="col-xl-12 col-12 mb-4"  >
                    <div class="card" >
                        <div class="card-header card-bg  header-text-color"  style="background-color:#fff;">
                        อุปกรณ์ในระบบ
                        </div>
                        
                        
                    </div>
                </div>
                  <!-- จบ ส่วนของคำว่า "หน้าหลัก" -->
                  
                  <!-- เริ่มส่วนของ card-->

                     <!--  card คำขอที่อนุมัติแล้ว -->
                     <div class="col-xl-3 col-md-6 mb-4">
                      <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                          <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                              <div class=" h6 font-weight-bold text-primary  mb-1">จำนวนที่ชนิดอุปกรณ์</div>
                              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $COUNT_product;?> ชนิด</div>
                            </div>
                            <div class="col-auto">
                              <i class="fas fa-mail-bulk fa-2x "></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <!--  card คำขอที่อนุมัติแล้ว -->
                    <div class="col-xl-3 col-md-6 mb-4">
                    <a href="Admin_add_accessories.php" style="text-decoration: none" >
                        <div class="card border-left-info shadow h-100 py-2">
                          <div class="card-body">
                            <div class="row no-gutters align-items-center">
                              <div class="col mr-2">
                                <div class=" h6 font-weight-bold text-info  mb-1">เพิ่มชนิดอุปกรณ์</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">+1 ชนิดอุปกรณ์</div>
                              </div>
                              <div class="col-auto text-info">
                              <i class="fas fa-plus-circle fa-3x"></i>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </a>
                    
              <!-- จบส่วนของ card-->
                 
              
            </div>
        <!-- จบ -->
         <!-- ส่วนของตาราง รายการขอยื่ม -->
         <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="h5 m-0 font-weight-bold text-primary">ชนิดอุปกรณ์ในระบบ</h6>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <colgroup>
                        <col  width="20">
                        <col  width="100">
                        <col  width="100">
                        <col  width="200">
                        <col  width="100">
                        <col  width="100">
                        <col  width="100">
                      </colgroup>
                      <thead>
                        <tr>
                          <th>ภาพ</th>
                          <th>ชื่ออุปกรณ์</th>
                          <th>หมายหมู่</th>
                          <th>รายละเอียด</th>
                          <th>จำนวนอุปกรณ์</th>
                          <th>สิทธิการยืม</th>
                          <th>จัดการ</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                        <th>ภาพ</th>
                          <th>ชื่ออุปกรณ์</th>
                          <th>หมายหมู่</th>
                          <th>รายละเอียด</th>
                          <th>จำนวนอุปกรณ์</th>
                          <th>สิทธิการยืม</th>
                          <th>จัดการ</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        <?php
                          $stml = get_all_product();
                         while ($get_all_product = $stml->fetch(PDO::FETCH_OBJ)){?>
                         <tr>
                          <td><img src="<?php echo "./img_product/".$get_all_product->picPath?>" alt="Lights" style="width:100%;max-width:100px"></td>
                          <td><?php echo "$get_all_product->pName" ;?></td>
                          <td><?php echo "$get_all_product->cName" ;?></td>
                          <td><?php echo "$get_all_product->detail" ;?></td>
                          <td><?php echo "$get_all_product->countP" ;?></td>
                          <td>
                            <button type="button" id="btn_comfirm" data-toggle="tooltip" title="" class="btn <?php if($get_all_product->claim_Admin == 1){echo "btn-success" ;}else{echo "btn-secondary" ;} ?> btn-sm btn-circle tt" data-original-title="เจ้าหน้าที่">A</button>
                            <button type="button" id="btn_comfirm" data-toggle="tooltip" title="" class="btn <?php if($get_all_product->claim_Teacher == 1){echo "btn-success" ;}else{echo "btn-secondary" ;} ?> btn-sm btn-circle tt" data-original-title="อาจารย์">T</button>
                            <button type="button" id="btn_comfirm" data-toggle="tooltip" title="" class="btn <?php if($get_all_product->claim_borrow == 1){echo "btn-success" ;}else{echo "btn-secondary" ;} ?> btn-sm btn-circle tt" data-original-title="ผู้ยืม">B</button>
                          </td>
                          <td style="text-align:center;">
                              <button  type="button" onclick="<?php if($get_all_product->lock == 1){echo "lock_ed_openlock('$get_all_product->pName','$get_all_product->pid')" ;}else{echo "lock_ed_lock('$get_all_product->pName','$get_all_product->pid')"  ;} ?>" class="btn <?php if($get_all_product->lock == 1){echo "btn-danger" ;}else{echo "btn-success" ;} ?> btn-sm " data-toggle="tooltip" title="" data-original-title="<?php if($get_all_product->lock == 1){echo "กดเปิดให้ยืม" ;}else{echo "กดปิดไม่ให้ยืม" ;} ?>"><i class="<?php if($get_all_product->lock == 1){echo "fas fa-lock" ;}else{echo "fas fa-lock-open" ;} ?>" aria-hidden="true"></i></button>
                              <a href="Admin_ed_accessories.php?pid=<?php echo $get_all_product->pid ?>"><button type="button" class="btn btn-warning btn-sm " data-toggle="tooltip" title="" data-original-title="แก้ไข"><i class="fas fa-edit" aria-hidden="true"></i></button></a>
                              <button type="button" class="btn btn-danger btn-sm" data-toggle="tooltip" title="" data-original-title="ลบ" onclick="delfunction('<?php echo $get_all_product->pName ?>','<?php echo $get_all_product->pid ?>')" ><i class="far fa-trash-alt" aria-hidden="true"></i></button>
                          </td>
                        </tr>
                        <?php
                        }  
                        ?>
                     <!-- fas fa-lock-open fas fa-lock-->
                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
        <!-- จบ ส่วนของตาราง รายการรออนุมัติ-->
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 
 
</body>

</html>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<script>
 

  //  ฟังก์ชันลบ
  function delfunction(name,id) {
  swal({
          title: "คุณแน่ใจหรือไม่?",
          text: "คุณต้องการลบ"+name,
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          cancelButtonClass: "btn-secondary",
          confirmButtonText: "ยืนยัน",
          cancelButtonText: "ยกเลิก",
          closeOnConfirm: false,
          closeOnCancel: true
      },
      function(isConfirm) {
          if (isConfirm) {
              swal({
                  title: "ลบเรียบร้อยแล้ว",
                  type: "success",
                  confirmButtonClass: "btn-danger",
                  confirmButtonText: "ตกลง",
                  closeOnConfirm: false,
              });
              delete_1(id);
              setTimeout(function() {
                location.reload();
              }, 1000);
          } else {

          }
      });
  }
  function delete_1(id1) {
      $.ajax({
        type: "POST",
        data: {
          id1: id1,
          delete: "delete"
        },
        url: "./mamage_p_accesspries.php",
        async: false,
        success: function(result) {}
      });
    }
  //  ฟังก์ชันลบ


  // ปิดให้ยืมอุปกรณ์
  function lock_ed_lock(name,id) {

  swal({
        
          title: "คุณแน่ใจที่จะปิดการยืม",
          text: name,
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          cancelButtonClass: "btn-secondary",
          confirmButtonText: "ยืนยัน",
          cancelButtonText: "ยกเลิก",
          closeOnConfirm: false,
          closeOnCancel: true
      },
      function(isConfirm) {
          if (isConfirm) {
              swal({
                  title: "ปิดให้ยืมเรียบร้อยแล้ว",
                  type: "success",
                  confirmButtonClass: "btn-danger",
                  confirmButtonText: "ตกลง",
                  closeOnConfirm: false,
              });
              lock_1(id);
              setTimeout(function() {
                location.reload();
              }, 1000);
          } else {

          }
      });
  }
  function lock_1(id1) {
      $.ajax({
        type: "POST",
        data: {
          id1: id1,
          lock: "lock"
        },
        url: "./mamage_p_accesspries.php",
        async: false,
        success: function(result) {}
      });
    }

  // ปิดให้ยืมอุปกรณ์

  // เปิดให้ยืมอุปกรณ์
  function lock_ed_openlock(name,id) {

  swal({
        
          title: "คุณแน่ใจที่จะเปิดการยืม",
          text: name,
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          cancelButtonClass: "btn-secondary",
          confirmButtonText: "ยืนยัน",
          cancelButtonText: "ยกเลิก",
          closeOnConfirm: false,
          closeOnCancel: true
      },
      function(isConfirm) {
          if (isConfirm) {
              swal({
                  title: "เปิดให้ยืมเรียบร้อยแล้ว",
                  type: "success",
                  confirmButtonClass: "btn-danger",
                  confirmButtonText: "ตกลง",
                  closeOnConfirm: false,
              });
              openlock_1(id);
              setTimeout(function() {
                location.reload();
              }, 1000);
          } else {

          }
      });
  }
  function openlock_1(id1) {
      $.ajax({
        type: "POST",
        data: {
          id1: id1,
          openlock: "openlock"
        },
        url: "./mamage_p_accesspries.php",
        async: false,
        success: function(result) {}
      });
    }

  // เปิดให้ยืมอุปกรณ์


</script>