<?php
session_start(); 
include "../../query.php";
if(isset($_POST['delete'])){
    unset($_SESSION['array_lock'][$_POST['key']]);
    unset($_SESSION['array'][$_POST['key']]);
}

if(isset($_POST['delete_db'])){
    del_db_seruialnumber($_POST['sid']);
}
if(isset($_POST['lock'])){
    $_SESSION['array_lock'][$_POST['key']] = 1;
}
if(isset($_POST['openlock'])){
    $_SESSION['array_lock'][$_POST['key']] = 0;
}
if(isset($_POST['edit'])){
    $lock = $_SESSION['array_lock'][$_POST['numbermode_o']];
    unset($_SESSION['array'][$_POST['numbermode_o']]);
    unset($_SESSION['array_lock'][$_POST['numbermode_o']]);
    $_SESSION['array'][$_POST['e_numbermode']] = $_POST['e_numbermode'];
    $_SESSION['array_lock'][$_POST['e_numbermode']] =  $lock;
    header("location:./Admin_add_accessories.php");
}
if(isset($_POST['edit_db'])){
    $lock = $_SESSION['array_lock'][$_POST['numbermode_o']];
    unset($_SESSION['array'][$_POST['numbermode_o']]);
    unset($_SESSION['array_lock'][$_POST['numbermode_o']]);
    $_SESSION['array'][$_POST['e_numbermode']] = $_POST['e_numbermode'];
    $_SESSION['array_lock'][$_POST['e_numbermode']] =  $lock;
    header("location:./Admin_ed_accessories.php?pid=".$_POST['pid']."");
}
if(isset($_POST['edit_db_2'])){
    up_db_seruialnumber($_POST['serialNum'],$_POST['sid']);
    header("location:./Admin_ed_accessories.php?pid=".$_POST['pid_db']."");
}
if(isset($_POST['lock_db'])){
    up_lock_db_seruialnumber(1,$_POST['key']);
}
if(isset($_POST['openlock_db'])){
    up_lock_db_seruialnumber(0,$_POST['key']);
}

?>