<?php
require_once("../../dbConnect.php");
//session_start();
$action = $_POST['action'] ?? "";


session_start();
if (isset($_POST['delete'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM `db_category` WHERE db_category.cid = $id";
    deletedata($sql);
}

if (isset($_POST['add'])) {
    $category = $_POST['cName'];

    $sqluser = "INSERT INTO `db_category`(`cid`, `cName`) VALUES (NULL,'$category')";
    echo $sqluser;
    addinsertData($sqluser);



    header("location: ./category.php");
}
if (isset($_POST['edit'])) {
    $e_categoryid = $_POST['e_categoryid'];
    $e_categoryname = $_POST['e_categoryname'];
    //echo ("$e_categoryid    ");
    //echo "'$e_categoryname'   ";

    $sql_editCate = "UPDATE db_category SET cid = $e_categoryid, `cName` = '$e_categoryname' WHERE db_category.cid =  $e_categoryid ";
    updateData($sql_editCate);

    //echo ($sql_editCate);

    header("location:./category.php");
}
