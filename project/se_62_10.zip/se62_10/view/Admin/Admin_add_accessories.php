<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<?php 
session_start(); 
// ข้อมูลของคนที่เข้ามา

// try {
//   if (!isset($_SESSION['login'])) {
//     header("Location: ../../index.php?error=เกินข้อผิดพราด!");
//     if(isset($_SESSION['jpg']) && $_SESSION['jpg']!=""){
//       echo "|".$_SESSION['jpg']."|";
//     }
// }
// }
// catch(Exception $e) {
//   echo "Access denied: No Permission to view this page";
//   exit(1);
// }
?>

<!DOCTYPE html>
<html lang="en">

<head>
 
  <?php include "link.php"?>
  <?php include "../../query.php" ?>
  <?php include "serial_number_mode.php" ?>
  <?php include "serial_number_mode_ed.php" ?>
  
<title>ระบบยืมของภาควิชาคอม</title>
<meta charset="UTF-8">
</head>

<body id="page-top">
  <div id="wrapper" >

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
      <?php include "logout1.php" ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content" >

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
       
          <div class="container-fluid">

           

        <!-- เริ่ม -->
        <div >
          <div class="row">
              <div class="col-xl-12 col-12 mb-4">
                  <div class="card">
                      <div class="card-header card-bg">
                          อุปกรณ์
                      </div>
                  </div>
              </div>
          </div>
          <div class="row">
              <div class="col-xl-4 col-12 mb-4">
                  <div class="row">
                      <div class="col-xl-12 col-12">
                          <div class="card">
                              <div class="card-header card-bg">
                                  รูปอุปกรณ์
                              </div>
                              <div class="card-body">
                                  <div class="row">
                                  <img id="uploadPreview" src="<?php if((isset($_SESSION['jpg']) && $_SESSION['jpg']!="")){echo "./img_product/".$_SESSION['jpg'] ;}else{echo"./img_product/Add_Image.png";}?>" alt="Lights" style="width:300px;max-width:400px;" >
                                  </div>
                                  <div class="row mt-3">
                                      <div class="col-xl-12 col-12">
                                        
                                          <!-- <input id="uploadImage" type="file" name="uploadImage" onchange="PreviewImage();"  /> -->
                                          <form class="imgForm" action="leanform.php" method="post" enctype="multipart/form-data">
                                            <input id="uploadImage" type="file" name="upload" onchange="PreviewImage();" />
                                            <input type="submit"  name="save"  value="upload" />
                                        </form>
                                      </div>
                                  </div>
                                  
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <form class="col-xl-8 col-12 mb-4"  method="post" id="formEdit" name="formEdit" action="mamage_p_add.php">
                  <div class="card">
                      <div class="card-header card-bg">
                          รายละเอียดอุปกรณ์
                      </div>
                      <div class="card-body">
                          <div class="row mb-4">
                              <div class="col-xl-3 col-12 text-right">
                                  <span>ชื่ออุปกรณ์</span>
                              </div>
                              <div class="col-xl-9 col-12">
                                <input name="firstname" type="text" class="form-control" id="firstname">
                              </div>
                          </div>
                          <div class="row mb-4">
                              <div class="col-xl-3 col-12 text-right">
                                  <span>หมวดหมู่</span>
                              </div>
                              <div class="col-xl-9 col-12">
                              <select class="form-control" id="cars" name="category" >
                              <option disabled="" selected="" id="province_list">เลือกหมวดหมู่</option>
                                <?php
                                $stml = get_category();
                                while ($get_category = $stml->fetch(PDO::FETCH_OBJ)){?>
                                  <option value="<?php echo $get_category->cid;?>"><?php echo $get_category->cName;?></option>
                              <?php
                                }  
                                ?>
                            
                              </select>
                              </div>
                          </div>
                          <div class="row mb-4">
                              <div class="col-xl-3 col-12 text-right">
                                  <span>รายละเอียด</span>
                              </div>
                              <div class="col-xl-9 col-12">
                              <textarea name="details"  style="resize:none;" class="form-control rounded-0" id="exampleFormControlTextarea2" rows="3"></textarea>
                              </div>
                          </div>
                        
                          <div class="row mb-4">
                              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 text-right">
                                  <span>สิทธิการยืม</span>
                              </div>
                              <div class="col-lg-9 col-md-8 col-sm-12 col-xs-12">

                                  <div class="form-check form-check-inline">
                                      <input class="form-check-input" type="checkbox" id="check1" name="check1" value="1">
                                      <label class="form-check-label" for="inlineCheckbox1">เจ้าหน้าที่</label>
                                  </div>
                                  <div class="form-check form-check-inline">
                                      <input class="form-check-input" type="checkbox" id="check2" name="check2" value="1">
                                      <label class="form-check-label" for="inlineCheckbox1">อาจารย์</label>
                                  </div>
                                  <div class="form-check form-check-inline">
                                      <input class="form-check-input" type="checkbox" id="check3" name="check3" value="1">
                                      <label class="form-check-label" for="inlineCheckbox1">นิสิต</label>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          
          </div>
        <!-- จบ -->
         <!-- ส่วนของตาราง รายการขอยื่ม -->
         <div class="card shadow mb-4">
              
                <div class="card-header py-3">
                  <h6 class="h5 m-0 font-weight-bold text-primary">ชนิดอุปกรณ์ในระบบ <button type="button" style="float:right;" class="btn btn-success" data-toggle="modal" data-target="#modal-1" onclick="number()">เพื่มเลขครุภัณฑ์</button> </h6>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <colgroup>
                      <col  width="100">
                        <col  width="100">
                        <col  width="100">
                        <col  width="100">
                      </colgroup>
                      <thead>
                        <tr>
                          <th>ลำดับ</th>
                          <th>เลขครุภัณฑ์</th>
                          <th>จัดการ</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <th>ลำดับ</th>
                          <th>เลขครุภัณฑ์</th>
                          <th>จัดการ</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        <?php 
                        $i = 1;
                        if(isset($_SESSION['array'])){
                        foreach ($_SESSION['array'] as $key => $val){?>
                        <tr>
                          <td><?php echo $i++;?></td>
                          <td><?php echo $val; ?></td>
                          <td style="text-align:center;">
                              <button  type="button" onclick="<?php if($_SESSION['array_lock'][$key] == 1){echo "lock_ed_openlock('$key')" ;}else{echo "lock_ed_lock('$key')"  ;} ?>" class="btn <?php if($_SESSION['array_lock'][$key] == 1){echo "btn-danger" ;}else{echo "btn-success" ;} ?> btn-sm " data-toggle="tooltip" title="" data-original-title="<?php if($_SESSION['array_lock'][$key] == 1){echo "กดเปิดให้ยืม" ;}else{echo "กดปิดไม่ให้ยืม" ;} ?>"><i class="<?php if($_SESSION['array_lock'][$key] == 1){echo "fas fa-lock" ;}else{echo "fas fa-lock-open" ;} ?>" aria-hidden="true"></i></button>
                              <button type="button" onclick="successmode_ed('<?php echo $key ?>')" class="btn btn-warning btn-sm " data-toggle="tooltip" title="" data-original-title="แก้ไข"><i class="fas fa-edit" aria-hidden="true"></i></button>
                              <button type="button" onclick="delfunction('<?php echo $key ?>')" class="btn btn-danger btn-sm" data-toggle="tooltip" title="" data-original-title="ลบ" ><i class="far fa-trash-alt" aria-hidden="true"></i></button>
                          </td>
                        </tr>
                            
                        <?php
                        }
                        } 
                        ?>
                        <!-- <tr>
                          <td>1</td>
                          <td>1248541348</td>
                          <td>
                            -
                          </td>
                          <td style="text-align:center;">
                              <button type="button" class="btn btn-danger btn-sm " data-toggle="tooltip" title="" data-original-title="ไม่เปิดให้ยืม"><i class="fas fa-lock" aria-hidden="true"></i></button>
                              <button type="button" class="btn btn-warning btn-sm " data-toggle="tooltip" title="" data-original-title="แก้ไข"><i class="fas fa-edit" aria-hidden="true"></i></button>
                              <button type="button" class="btn btn-danger btn-sm" data-toggle="tooltip" title="" data-original-title="ลบ" ><i class="far fa-trash-alt" aria-hidden="true"></i></button>
                          </td>
                        </tr> -->
                      </tbody>
                    </table>
                    
                  </div>
                  <br>
                  <div class="modal-footer">
                    <a> <button type="submit" class="btn btn-success" name="submit">ยืนยัน</button></a>
                    <a class="nav-link" href="Admin_accessories.php" ><button type="button" class="btn btn-danger"  >ยกเลิก</button></a>
                  </div>
                </div>
                
              </div>
              </form>
        <!-- จบ ส่วนของตาราง รายการรออนุมัติ-->

        </div>
        <!-- /.container-fluid -->
   

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 
 
</body>

</html>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});

function number() {
    $("#numbermode").modal('show');
   
  }

  function successmode_ed($key) {
    $("#numbermode_ed").modal('show');
    $('#e_numbermode').val($key);
    $('#numbermode_o').val($key);
  }
</script>
<script type="text/javascript">

    function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);
        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
           
        };
    };
    

</script>


<script>
 

  //  ฟังก์ชันลบ
  function delfunction(key) {

  swal({
          title: "คุณแน่ใจหรือไม่?",
          text: key,
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          cancelButtonClass: "btn-secondary",
          confirmButtonText: "ยืนยัน",
          cancelButtonText: "ยกเลิก",
          closeOnConfirm: false,
          closeOnCancel: true
      },
      function(isConfirm) {
          if (isConfirm) {
              swal({
                  title: "ลบเรียบร้อยแล้ว",
                  type: "success",
                  confirmButtonClass: "btn-danger",
                  confirmButtonText: "ตกลง",
                  closeOnConfirm: false,
              });
              delete_1(key);
              setTimeout(function() {
                location.reload();
              }, 1000);
          } else {

          }
      });
  }
  function delete_1(key) {
      $.ajax({
        type: "POST",
        data: {
          key: key,
          delete: "delete"
        },
        url: "./mamage_p_add_2.php",
        async: false,
        success: function(result) {}
      });
    }
  //  ฟังก์ชันลบ


  // ปิดให้ยืมอุปกรณ์
  function lock_ed_lock(key) {

  swal({
        
          title: "คุณแน่ใจที่จะปิดการยืม",
          text: key,
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          cancelButtonClass: "btn-secondary",
          confirmButtonText: "ยืนยัน",
          cancelButtonText: "ยกเลิก",
          closeOnConfirm: false,
          closeOnCancel: true
      },
      function(isConfirm) {
          if (isConfirm) {
              swal({
                  title: "ปิดให้ยืมเรียบร้อยแล้ว",
                  type: "success",
                  confirmButtonClass: "btn-danger",
                  confirmButtonText: "ตกลง",
                  closeOnConfirm: false,
              });
              lock_1(key);
              setTimeout(function() {
                location.reload();
              }, 1000);
          } else {

          }
      });
  }
  function lock_1(key) {
      $.ajax({
        type: "POST",
        data: {
          key: key,
          lock: "lock"
        },
        url: "./mamage_p_add_2.php",
        async: false,
        success: function(result) {}
      });
    }

  // ปิดให้ยืมอุปกรณ์

  // เปิดให้ยืมอุปกรณ์
  function lock_ed_openlock(key) {

  swal({
        
          title: "คุณแน่ใจที่จะเปิดการยืม",
          text: key,
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          cancelButtonClass: "btn-secondary",
          confirmButtonText: "ยืนยัน",
          cancelButtonText: "ยกเลิก",
          closeOnConfirm: false,
          closeOnCancel: true
      },
      function(isConfirm) {
          if (isConfirm) {
              swal({
                  title: "เปิดให้ยืมเรียบร้อยแล้ว",
                  type: "success",
                  confirmButtonClass: "btn-danger",
                  confirmButtonText: "ตกลง",
                  closeOnConfirm: false,
              });
              openlock_1(key);
              setTimeout(function() {
                location.reload();
              }, 1000);
          } else {

          }
      });
  }
  function openlock_1(key) {
      $.ajax({
        type: "POST",
        data: {
          key: key,
          openlock: "openlock"
        },
        url: "./mamage_p_add_2.php",
        async: false,
        success: function(result) {}
      });
    }

  // เปิดให้ยืมอุปกรณ์


</script>
