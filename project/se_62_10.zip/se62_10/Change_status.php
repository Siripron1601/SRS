<?php
$s = $_GET['s'];
$uid = $_GET['uid'];
if($s==1){
    $status = 1;
    $isAdmin = 0;
}elseif($s==2){
    $status = 2;
    $isAdmin = 1;
}else{
    $status = 3;
    $isAdmin = 0;
}
require('connect.php');
$con->query("UPDATE `db_user` SET `status` = '$status', `isAdmin` = '$isAdmin' WHERE `db_user`.`uid` = '$uid'");
$con->query("UPDATE `dim_user` SET `status` = '$status' WHERE `dim_user`.`uid` = '$uid'");
header("Location: index.php?error=ต้องเข้าระบบใหม่?");


?>