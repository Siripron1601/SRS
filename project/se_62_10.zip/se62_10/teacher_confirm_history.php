<?php 
session_start(); 

try {
  if (!isset($_SESSION['login'])) {
    header("Location: ../../index.php?error=เกินข้อผิดพราด!");
}
}
catch(Exception $e) {
  echo "Access denied: No Permission to view this page";
  exit(1);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <?php include "link.php"?>
  <?php include "../../query.php"?>
<title>ระบบยืมของภาควิชาคอม</title>
</head>

<body id="page-top">
  <div id="wrapper" >

    <!-- อันนี้ไว้เรียกใช้แท็บข้างๆๆ -->
      <?php include "logout2.php" ?>
    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column" style="background-color: #EBF5FB;">

      <!-- Main Content -->
      <div id="content" >

        <!-- อันนี้ไว้เรียกใช้แท็บบน -->
        <?php include "Topbar.php" ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

           

        <!-- เริ่ม -->
            <div class="row" >

                  <!-- ส่วนของคำว่า "หน้าหลัก" -->
                <div class="col-xl-12 col-12 mb-4"  >
                    <div class="card" >
                        <div class="card-header card-bg  header-text-color"  style="background-color:#fff;">
                        หน้าประวัติการอนุมัติ
                           
                        </div>
                        
                        
                    </div>
                </div>
                  <!-- จบ ส่วนของคำว่า "หน้าหลัก" -->
                  
                  <!-- เริ่มส่วนของ card-->

                    <!--  card คำขอที่รอการอนุมัติ -->
                    <!-- <div class="col-xl-3 col-md-6 mb-4">
                      <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                          <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                              <div class=" h6 font-weight-bold text-primary  mb-1">รอส่งคืน</div>
                              <div class="h5 mb-0 font-weight-bold text-gray-800">2 คำขอ</div>
                            </div>
                            <div class="col-auto">
                              <i class="fas fa-mail-bulk fa-2x "></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div> -->

                    
              <!-- จบส่วนของ card-->
                 
              
            </div>
        <!-- จบ -->
  

         <!-- ส่วนของตาราง รายการขอยื่ม -->
         <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="h5 m-0 font-weight-bold text-primary">ประวัติการอนุมัติ</h6>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                      <colgroup>
                        <col  width="20">
                        <col  width="20">
                        
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                        <col  width="20">
                      </colgroup>
                      <thead>
                        <tr>
                          <th>รหัสรายการ</th>
                          <th>วันที่ทำเรื่อง</th>
                          <th>รหัสประจำตัว</th>
                          <th>ชื่อ-นามสกุล</th>
                          <th>หมายเหตุ</th>
                          <th>สถานะ</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <th>รหัสรายการ</th>
                          <th>วันที่ทำเรื่อง</th>
                          <th>รหัสประจำตัว</th>
                          <th>ชื่อ-นามสกุล</th>
                          <th>หมายเหตุ</th>
                          <th>สถานะ</th>
                        </tr>
                      </tfoot>
                      <tbody>
                        <?php
                           $stml = get_db_teacher($_SESSION['login']['formalId']);
                           while ($get_db_teacher = $stml->fetch(PDO::FETCH_OBJ)){
                             $tid = $get_db_teacher->tid;
                           }
                           $stml = get_DIM_teacher($tid);
                           while ($get_DIM_teacher = $stml->fetch(PDO::FETCH_OBJ)){
                             $DIM_tid = $get_DIM_teacher->dim_id;
                           }
                           $stml = get_history($DIM_tid);
                           $h = 4; //จำนวนหลัก
                           while ($get_history = $stml->fetch(PDO::FETCH_OBJ)){?>
                            <tr>
                              <td><?php $id = $get_history->log_id;  echo "A", sprintf("%0" . $h . "d", $id);  $id = "A". sprintf("%0" . $h . "d", $id);?></td>
                              <td><?php echo $get_history->date ?></td>
                              <td><?php echo $get_history->stCode?></td>
                              <td><?php echo $get_history->title." ".$get_history->firstname." ".$get_history->lastname ;  ?></td>
                              <td><?php echo $get_history->confirm_note?></td>
                              <td>
                                <?php
                                if($get_history->status_borrow== '2'){
                                  echo "ปฎิเสธคำขอ";
                                }else{
                                  echo "อนุมัติ";
                                }
                                ?>


                              </td>
                            </tr>
                            <?php
                          }
                        
                        ?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
        <!-- จบ ส่วนของตาราง รายการรออนุมัติ-->
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->


    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

 
 
</body>

</html>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>