<?php

// ดึงค่าข้อมูลของ User ที่มีอยู่ในระบบ
function get_User($formalId){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `db_user` WHERE `formalId` ='$formalId'");
    return $stmt;
}

// เพิ่มข้อมูล User ในระบบ
function Add_User($formalId,$title,$firstname,$lastname,$status,$email){
    require('connect.php');
    $con->query("INSERT INTO `db_user` (`uid`, `formalId`, `title`, `firstname`, `lastname`, `status`, `isAdmin`, `email`) VALUES (NULL, '$formalId', '$title', '$firstname', '$lastname', '$status', '0', '$email')");
    $stml = $con->query("select max(uid)AS uid from `db_user`");
    while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
        $uid = $DB_user->uid;
        Add_DIM_User($formalId,$uid,$title,$firstname,$lastname,$status,$email);
    }  
}

function Add_DIM_User($stCode,$uid,$title,$firstname,$lastname,$status,$email){
    require('connect.php');
    $con->query("INSERT INTO `dim_user` (`dim_id`, `stCode`, `uid`, `title`, `firstname`, `lastname`, `status`, `email`) VALUES (NULL, '$stCode', '$uid', '$title', '$firstname', '$lastname', '$status', '$email')");
}

// หน้า admin หน้าหลัก
function get_P_admin(){
    require('connect.php');
    $stmt = $con->query("SELECT `log_order`.`log_id`,`log_order`.`date`,`log_order`.`confirm_note`,`dim_user`.`stCode`,`dim_user`.`title`AS title_user,`dim_user`.`firstname`AS firstname_user,`dim_user`.`lastname`AS lastname_user,`dim_user`.`status`AS status_user,`dim_teacher`.`title`,`dim_teacher`.`firstname`,`dim_teacher`.`lastname`,countP FROM `log_order` INNER JOIN `dim_user` ON `dim_user`.`dim_id` = `log_order`.`dim_uid` LEFT JOIN `dim_teacher` ON `dim_teacher`.`dim_id` = `log_order`.`dim_tid` INNER JOIN (SELECT COUNT(`log_id`) AS countP ,`log_orderid` FROM `log_detailborrow` WHERE ISNULL(`endT`) GROUP BY `log_orderid`)AS T1 ON T1.`log_orderid` = `log_order`.`log_id` WHERE `status_borrow` = '3'");
    return $stmt;
}

function get_P_waitback(){
    require('connect.php');
    $stmt = $con->query("SELECT `log_order`.`log_id`,`log_order`.`date`,`log_order`.`confirm_note`,`dim_user`.`stCode`,`dim_user`.`title`AS title_user,`dim_user`.`firstname`AS firstname_user,`dim_user`.`lastname`AS lastname_user,`dim_user`.`status`AS status_user,`dim_teacher`.`title`,`dim_teacher`.`firstname`,`dim_teacher`.`lastname`,countP , `log_order`.`date_Pick_up` FROM `log_order` INNER JOIN `dim_user` ON `dim_user`.`dim_id` = `log_order`.`dim_uid` LEFT JOIN `dim_teacher` ON `dim_teacher`.`dim_id` = `log_order`.`dim_tid` INNER JOIN (SELECT COUNT(`log_id`) AS countP ,`log_orderid` FROM `log_detailborrow` WHERE ISNULL(`endT`) GROUP BY `log_orderid`)AS T1 ON T1.`log_orderid` = `log_order`.`log_id` WHERE `status_borrow` = '4'");
    return $stmt;
}

// จำนวนรายการที่ผ่านการอนุมีตื
function get_count_order(){
    require('connect.php');
    $stmt = $con->query("SELECT COUNT(`log_order`.`log_id`)AS COUNT_ORDER FROM `log_order` WHERE `status_borrow` = '3' ");
    return $stmt;
}

// ดึงค่าตารางรายการอปุกรณ์ที่ยืม ผ่านการอนุมีติ
function get_lod_detailborrow($log_orderid){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `log_detailborrow`INNER JOIN `dim_product` ON `dim_product`.`dimProduct` = `log_detailborrow`.`dim_product` WHERE `log_detailborrow`.`log_orderid` = '$log_orderid'");
    return $stmt;
}

// มารับของ
function up_log_order($log_id){
    require('connect.php');
    $timestamp = time(); 
    $date_Pick_up = date("Y-m-d", $timestamp);
    $con->query("UPDATE `log_order` SET `status_borrow` = '4', `date_Pick_up` = '$date_Pick_up' WHERE `log_order`.`log_id` = $log_id;");
}

// ยืมไม่สำเร็จ
function up_log_order_danger($log_id,$confirm_note){
    require('connect.php');
    $timestamp = time(); 
    $date_Pick_up = date("Y-m-d", $timestamp);
    $con->query("UPDATE `log_order` SET `status_borrow` = '5', `date_Pick_up` = '$date_Pick_up' ,`confirm_note` = '$confirm_note'  WHERE `log_order`.`log_id` = $log_id;");
}


function get_count_product(){
    require('connect.php');
    $stmt = $con->query("SELECT COUNT(`pid`)AS COUNT_product FROM `db_product` ");
    return $stmt;
}


function get_all_product(){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `db_product`LEFT JOIN (SELECT `db_serialnumber`.`pid`AS PID, COUNT(`db_serialnumber`.`sid`) AS countP FROM `db_serialnumber` GROUP BY `db_serialnumber`.`pid`)AS T1 ON T1.`pid` = `db_product`.`pid` LEFT JOIN (SELECT `cid`AS CID, `cName` FROM `db_category`)AS T2 ON T2.`cid` = `db_product`.`cid`");
    return $stmt;
}

function get_product($pid){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `db_product` WHERE `pid` = '$pid'");
    return $stmt;
}

function get_serialnumber($pid){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `db_serialnumber` WHERE `pid` = '$pid'");
    return $stml ;
}


function get_category(){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `db_category`");
    return $stmt;
}


function Add_product($pName,$cid,$detail,$picPath,$claim_Admin,$claim_Teacher,$claim_borrow){
    require('connect.php');
    $con->query("INSERT INTO `db_product` (`pid`, `pName`, `cid`, `detail`, `picPath`, `claim_Admin`, `claim_Teacher`, `claim_borrow`) 
    VALUES (NULL, '$pName', '$cid', '$detail', '$picPath', '$claim_Admin', '$claim_Teacher', '$claim_borrow')");
    $stml = $con->query("select max(pid)AS pid from `db_product`");
    while ($db_product = $stml->fetch(PDO::FETCH_OBJ)){
        $pid = $db_product->pid;
        Add_serialnumber($pid,$pName,$cid,$detail,$picPath,$claim_Admin,$claim_Teacher,$claim_borrow);
    }  

}
function Add_serialnumber($pid,$pName,$cid,$detail,$picPath,$claim_Admin,$claim_Teacher,$claim_borrow){
    require('connect.php');
    foreach ($_SESSION['array'] as $key => $val){
        $con->query("INSERT INTO `db_serialnumber` (`sid`, `pid`, `serialNum`, `status`) VALUES (NULL, '$pid', '$val', 'อยู่ในระบบ')");
        $stml = $con->query("select max(sid)AS sid from `db_serialnumber`");
        while ($db_serialnumber = $stml->fetch(PDO::FETCH_OBJ)){
            $sid = $db_serialnumber->sid;
            Add_DIM_product($sid,$pid,$val,$pName,$cid,$detail);
        }  
        
    }
    unset($_SESSION["array"]);
}

function Add_DIM_product($sid,$pid,$val,$pName,$cid,$detail){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `db_category` WHERE `cid`='$cid'");
    while ($db_category = $stml->fetch(PDO::FETCH_OBJ)){
       $cName = $db_category->cName;
    }  
    $con->query("INSERT INTO `dim_product` (`dimProduct`, `pid`, `cid`, `sid`, `pName`, `cName`, `detail`, `serialNum`) 
    VALUES (NULL, '$pid', '$cid', '$sid', '$pName', '$cName', '$detail', '$val')");
}


function del_db_product($pid){
    require('connect.php');
    $con->query("DELETE FROM `db_product` WHERE `db_product`.`pid` = '$pid'");
}


function up_lock_db_product($pid){
    require('connect.php');
    $con->query("UPDATE `db_product` SET `lock` = '1' WHERE `db_product`.`pid` = '$pid'");
}
function up_openlock_db_product($pid){
    require('connect.php');
    $con->query("UPDATE `db_product` SET `lock` = '0' WHERE `db_product`.`pid` = '$pid'");
}

function up_lock_db_seruialnumber($lock_ser,$sid){
    require('connect.php');
    $con->query("UPDATE `db_serialnumber` SET `lock_ser` = '$lock_ser' WHERE `db_serialnumber`.`sid` = '$sid'");
}
function up_db_seruialnumber($serialNum,$sid){
    require('connect.php');
    $con->query("UPDATE `db_serialnumber` SET `serialNum` = '$serialNum' WHERE `db_serialnumber`.`sid` = '$sid'");
}
function del_db_seruialnumber($sid){
    require('connect.php');
    $con->query("DELETE FROM `db_serialnumber` WHERE `db_serialnumber`.`sid` = '$sid'");
}


function up_db_product($pid,$pName,$cid,$detail,$picPath,$claim_Admin,$claim_Teacher,$claim_borrow){
    require('connect.php');
    $con->query("UPDATE `db_product` SET `pName` = '$pName', `cid` = '$cid', `detail` = '$detail', `picPath` = '$picPath', `claim_Admin` = '$claim_Admin', `claim_Teacher` = '$claim_Teacher', `claim_borrow` = '$claim_borrow' WHERE `db_product`.`pid` = '$pid'");
    foreach ($_SESSION['array'] as $key => $val){
        $con->query("INSERT INTO `db_serialnumber` (`sid`, `pid`, `serialNum`, `status`) VALUES (NULL, '$pid', '$val', 'อยู่ในระบบ')");
        $stml = $con->query("select max(sid)AS sid from `db_serialnumber`");
        while ($db_serialnumber = $stml->fetch(PDO::FETCH_OBJ)){
            $sid = $db_serialnumber->sid;
            Add_DIM_product($sid,$pid,$val,$pName,$cid,$detail);
        }  
    }
    unset($_SESSION["array"]);
}

function get_all_page($claim,$isAdmin){
    require('connect.php');
    if($claim==1){
        $stmt = $con->query("SELECT * FROM `db_product` INNER JOIN (SELECT `cid`AS CID,`cName` FROM`db_category`)AS T1 ON T1.CID = `db_product`.`cid` LEFT JOIN (SELECT `pid`AS PID ,COUNT(`sid`)AS countS  FROM `db_serialnumber` WHERE `status` = 'อยู่ในระบบ' GROUP BY `pid`)AS T2 ON T2.PID = `db_product`.`pid` WHERE `db_product`.`lock`= '0' AND `claim_Teacher` = '1'");
    }elseif($isAdmin == 1){
        $stmt = $con->query("SELECT * FROM `db_product` INNER JOIN (SELECT `cid`AS CID,`cName` FROM`db_category`)AS T1 ON T1.CID = `db_product`.`cid` LEFT JOIN (SELECT `pid`AS PID ,COUNT(`sid`)AS countS  FROM `db_serialnumber` WHERE `status` = 'อยู่ในระบบ' GROUP BY `pid`)AS T2 ON T2.PID = `db_product`.`pid` WHERE `db_product`.`lock`= '0' AND `claim_Admin` = '1'");
    }else{
        $stmt = $con->query("SELECT * FROM `db_product` INNER JOIN (SELECT `cid`AS CID,`cName` FROM`db_category`)AS T1 ON T1.CID = `db_product`.`cid` LEFT JOIN (SELECT `pid`AS PID ,COUNT(`sid`)AS countS  FROM `db_serialnumber` WHERE `status` = 'อยู่ในระบบ' GROUP BY `pid`)AS T2 ON T2.PID = `db_product`.`pid` WHERE `db_product`.`lock`= '0' AND `claim_borrow` = '1'");
    }
    return $stmt;
}

function get_page($claim,$isAdmin,$cid){
    require('connect.php');
    if($claim==1){
        $stmt = $con->query("SELECT * FROM `db_product` INNER JOIN (SELECT `cid`AS CID,`cName` FROM`db_category`)AS T1 ON T1.CID = `db_product`.`cid` LEFT JOIN (SELECT `pid`AS PID ,COUNT(`sid`)AS countS  FROM `db_serialnumber` WHERE `status` = 'อยู่ในระบบ' GROUP BY `pid`)AS T2 ON T2.PID = `db_product`.`pid` WHERE `db_product`.`lock`= '0' AND `claim_Teacher` = '1' AND `db_product`.`cid` = '$cid'");
    }elseif($isAdmin == 1){
        $stmt = $con->query("SELECT * FROM `db_product` INNER JOIN (SELECT `cid`AS CID,`cName` FROM`db_category`)AS T1 ON T1.CID = `db_product`.`cid` LEFT JOIN (SELECT `pid`AS PID ,COUNT(`sid`)AS countS  FROM `db_serialnumber` WHERE `status` = 'อยู่ในระบบ' GROUP BY `pid`)AS T2 ON T2.PID = `db_product`.`pid` WHERE `db_product`.`lock`= '0' AND `claim_Admin` = '1' AND `db_product`.`cid` = '$cid'");
    }else{
        $stmt = $con->query("SELECT * FROM `db_product` INNER JOIN (SELECT `cid`AS CID,`cName` FROM`db_category`)AS T1 ON T1.CID = `db_product`.`cid` LEFT JOIN (SELECT `pid`AS PID ,COUNT(`sid`)AS countS  FROM `db_serialnumber` WHERE `status` = 'อยู่ในระบบ' GROUP BY `pid`)AS T2 ON T2.PID = `db_product`.`pid` WHERE `db_product`.`lock`= '0' AND `claim_borrow` = '1' AND `db_product`.`cid` = '$cid'");
    }
    return $stmt;
}

function get_db_teacher($formalId){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `db_teacher` WHERE `formalId` = '$formalId'");
    return $stml;
}

function get_all_db_teacher(){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `db_teacher`");
    return $stml;
}

function get_page_confirmation($pid){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `db_product` INNER JOIN (SELECT `cid`AS CID,`cName` FROM`db_category`)AS T1 ON T1.CID = `db_product`.`cid` LEFT JOIN (SELECT `pid`AS PID ,COUNT(`sid`)AS countS FROM `db_serialnumber` WHERE `status` = 'อยู่ในระบบ' GROUP BY `pid`)AS T2 ON T2.PID = `db_product`.`pid` WHERE `db_product`.`pid` = '$pid'");
    return $stml;
}

function get_DIM_user($uid){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `dim_user` WHERE `uid` = '$uid'");
    return $stml;
}

function get_DIM_teacher($tid){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `dim_teacher` WHERE `tid` = '$tid'");
    return $stml;
}

function get_DIM_Product_Admin($sid){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `dim_product` WHERE `sid` = '$sid'");
    return $stml;
}

function Add_log_detailborrow($log_orderid,$startT,$db_product_borrow){
    require('connect.php');
    $con->query("INSERT INTO `log_detailborrow` (`log_id`, `log_orderid`, `borrowNum`, `startT`, `endT`, `dim_product`, `db_product_borrow`) VALUES (NULL, '$log_orderid', '1', '$startT', NULL, NULL, '$db_product_borrow')");
}

function up_log_detailborrow_Admin($log_id,$pid){
    require('connect.php');
    $stml = $con->query("SELECT `pid`,MIN(`sid`)AS MINSID FROM `db_serialnumber` WHERE `pid` = '$pid' AND `status` = 'อยู่ในระบบ' GROUP BY `pid`");
    while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
        $MINSID = $DB_user->MINSID;
        $stml = get_DIM_Product_Admin($MINSID);
        while($get_DIM_Product_Admin = $stml->fetch(PDO::FETCH_OBJ)){
            $dim_product = $get_DIM_Product_Admin->dimProduct;
        }
    }
    $con->query("UPDATE `log_detailborrow` SET `dim_product` = '$dim_product' WHERE `log_detailborrow`.`log_id` = '$log_id'");
    $con->query("UPDATE `db_serialnumber` SET `status` = 'ถูกยืม' WHERE `db_serialnumber`.`sid` = '$MINSID'");
}



function Add_log_order_Admin($dim_uid,$dim_tid,$borrow_note,$basket){
    require('connect.php');
    $startT=time();
    $date = date("Y-m-d",$startT);
    $year = date("Y",$startT);
    $con->query("INSERT INTO `log_order` (`log_id`, `dim_uid`, `dim_tid`, `status_borrow`, `startT`, `endT`, `date`, `borrow_note`, `confirm_note`, `return_note`, `year`, `date_sanction`, `date_Pick_up`, `day_night`) 
    VALUES (NULL, '$dim_uid', NULL, '4', '$startT', NULL, '$date', '$borrow_note', NULL, NULL, '$year', NULL, NULL, NULL)");
      $stml = $con->query("select max(log_id)AS log_id from `log_order`");
      while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
          $log_orderid = $DB_user->log_id;
      }  
    foreach ($basket as $key => $val){
        Add_log_detailborrow($log_orderid,$startT,$val);
        $stml = $con->query("select max(log_id)AS log_id_orderid from `log_detailborrow`");
        while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
            $log_id_orderid = $DB_user->log_id_orderid;
            up_log_detailborrow_Admin($log_id_orderid,$val);
        }  

    }
}


function Add_log_order_Teacher($dim_uid,$dim_tid,$borrow_note,$basket){
    require('connect.php');
    $startT=time();
    $date = date("Y-m-d",$startT);
    $year = date("Y",$startT);
    $con->query("INSERT INTO `log_order` (`log_id`, `dim_uid`, `dim_tid`, `status_borrow`, `startT`, `endT`, `date`, `borrow_note`, `confirm_note`, `return_note`, `year`, `date_sanction`, `date_Pick_up`, `day_night`) 
    VALUES (NULL, '$dim_uid', NULL, '3', '$startT', NULL, '$date', '$borrow_note', NULL, NULL, '$year', NULL, NULL, NULL)");
      $stml = $con->query("select max(log_id)AS log_id from `log_order`");
      while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
          $log_orderid = $DB_user->log_id;
      }  
    foreach ($basket as $key => $val){
        Add_log_detailborrow($log_orderid,$startT,$val);
        $stml = $con->query("select max(log_id)AS log_id_orderid from `log_detailborrow`");
        while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
            $log_id_orderid = $DB_user->log_id_orderid;
            up_log_detailborrow_Admin($log_id_orderid,$val);
        }  

    }
}

function Add_log_order_User($dim_uid,$dim_tid,$borrow_note,$basket){
    require('connect.php');
    $startT=time();
    $date = date("Y-m-d",$startT);
    $year = date("Y",$startT);
    $con->query("INSERT INTO `log_order` (`log_id`, `dim_uid`, `dim_tid`, `status_borrow`, `startT`, `endT`, `date`, `borrow_note`, `confirm_note`, `return_note`, `year`, `date_sanction`, `date_Pick_up`, `day_night`) 
    VALUES (NULL, '$dim_uid', '$dim_tid', '1', '$startT', NULL, '$date', '$borrow_note', NULL, NULL, '$year', NULL, NULL, NULL)");
      $stml = $con->query("select max(log_id)AS log_id from `log_order`");
      while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
          $log_orderid = $DB_user->log_id;
      }  
    foreach ($basket as $key => $val){
        Add_log_detailborrow($log_orderid,$startT,$val);
    }
    return $log_orderid;
}

function get_email_user($log_order){
    require('connect.php');
    $stml = $con->query("SELECT `log_order`.`date`,`log_order`.`borrow_note`,`dim_user`.`title`AS title_user ,`dim_user`.`firstname`AS firstname_user,`dim_user`.`lastname`AS lastname_user,`dim_user`.`email`AS email_user ,`dim_teacher`.`title`,`dim_teacher`.`firstname`,`dim_teacher`.`lastname`,`dim_teacher`.`email`,`db_product`.`pName`,`log_detailborrow`.`borrowNum` ,`log_order`.`confirm_note` FROM `log_order` INNER JOIN `log_detailborrow` ON `log_detailborrow`.`log_orderid` = `log_order`.`log_id`INNER JOIN `dim_user`ON `dim_user`.`dim_id` = `log_order`.`dim_uid` INNER JOIN `dim_teacher` ON `dim_teacher`.`dim_id` = `log_order`.`dim_tid` INNER JOIN `db_product` ON `db_product`.`pid` = `log_detailborrow`.`db_product_borrow` 
    WHERE `log_order`.`log_id` = '$log_order'");
    return $stml;
}



// ส่วนของ อ.



function get_count_order_T($dim_tid){
    require('connect.php');
    $stmt = $con->query("SELECT COUNT(`log_id`) AS COUNTID FROM `log_order` WHERE `dim_tid` = '$dim_tid' AND `status_borrow` = '1'");
    return $stmt;
}

function get_All_order_T($dim_tid){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `log_order` INNER JOIN `dim_user` ON `dim_user`.`dim_id` = `log_order`.`dim_uid` INNER JOIN (SELECT `log_orderid` AS LOG_orderid ,COUNT(`log_id`)AS COUNT_DT FROM `log_detailborrow` GROUP BY `log_orderid`)AS T1 ON T1.LOG_orderid = `log_order`.`log_id` WHERE `dim_tid` = '$dim_tid' AND `status_borrow` = '1'");
    return $stmt;
}

function up_log_order_sanction($confirm_note,$date_sanction,$log_id){
    require('connect.php');
    $con->query("UPDATE `log_order` SET `status_borrow` = '3', `confirm_note` = '$confirm_note', `date_sanction` = '$date_sanction' WHERE `log_order`.`log_id` = '$log_id'");
    $stml = $con->query("SELECT * FROM `log_detailborrow` WHERE `log_orderid` = '$log_id'");
    while ($log_detailborrow = $stml->fetch(PDO::FETCH_OBJ)){
        $stml2 = $con->query("SELECT MAX(`sid`) AS MASSID FROM `db_serialnumber` WHERE `pid` = '$log_detailborrow->db_product_borrow'");
        while ($log_detailborrow_MAX = $stml2->fetch(PDO::FETCH_OBJ)){
            $MASSID = $log_detailborrow_MAX->MASSID;
        }
        $stml3 = get_DIM_Product_Admin($MASSID);
        while ($get_DIM_Product_Admin = $stml3->fetch(PDO::FETCH_OBJ)){
            $con->query("UPDATE `log_detailborrow` SET `dim_product` = '$get_DIM_Product_Admin->dimProduct' WHERE `log_detailborrow`.`log_id` = '$log_detailborrow->log_id'");
        }
        $con->query("UPDATE `db_serialnumber` SET `status` = 'ถูกยืม' WHERE `db_serialnumber`.`sid` = '$MASSID'");
    }  
}

function get_history_2($dim_tid){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `log_order` INNER JOIN `dim_user` ON `dim_user`.`dim_id` = `log_order`.`dim_uid` INNER JOIN (SELECT `log_orderid` AS LOG_orderid ,COUNT(`log_id`)AS COUNT_DT FROM `log_detailborrow` GROUP BY `log_orderid`)AS T1 ON T1.LOG_orderid = `log_order`.`log_id` WHERE `dim_tid` = '$dim_tid' AND (`status_borrow` = '6' OR `status_borrow` = '5')");
    return $stmt;
}

function get_history_3($dim_uid){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `log_order` INNER JOIN `dim_user` ON `dim_user`.`dim_id` = `log_order`.`dim_uid` INNER JOIN (SELECT `log_orderid` AS LOG_orderid ,COUNT(`log_id`)AS COUNT_DT FROM `log_detailborrow` GROUP BY `log_orderid`)AS T1 ON T1.LOG_orderid = `log_order`.`log_id` WHERE `log_order`.`dim_uid` = '$dim_uid' AND (`status_borrow` = '6' OR `status_borrow` = '5')");
    return $stmt;
}



function get_lod_detailborrow_T($log_orderid){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `log_detailborrow`INNER JOIN `db_product` ON `db_product`.`pid` = `log_detailborrow`.`db_product_borrow` WHERE `log_detailborrow`.`log_orderid` = '$log_orderid'");
    return $stmt;
}


function get_history($dim_tid){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `log_order` INNER JOIN `dim_user` ON `dim_user`.`dim_id` = `log_order`.`dim_uid` INNER JOIN (SELECT `log_orderid` AS LOG_orderid ,COUNT(`log_id`)AS COUNT_DT FROM `log_detailborrow` GROUP BY `log_orderid`)AS T1 ON T1.LOG_orderid = `log_order`.`log_id`  WHERE `dim_tid` = '$dim_tid' AND (`status_borrow` = '3' OR `status_borrow` = '4' OR `status_borrow` = '5'  OR `status_borrow` = '2')");
    return $stmt;
}

function get_waitback_T($dim_tid){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `log_order` INNER JOIN `dim_user` ON `dim_user`.`dim_id` = `log_order`.`dim_uid` INNER JOIN (SELECT `log_orderid` AS LOG_orderid ,COUNT(`log_id`)AS COUNT_DT FROM `log_detailborrow` GROUP BY `log_orderid`)AS T1 ON T1.LOG_orderid = `log_order`.`log_id`  WHERE `dim_tid` = '$dim_tid' AND (`status_borrow` = '3' OR `status_borrow` = '4' OR `status_borrow` = '5'  OR `status_borrow` = '2')");
    return $stmt;
}

// ส่วนของผู้ยืม

function get_count_order_user($dim_uid){
    require('connect.php');
    $stml = $con->query("SELECT COUNT(`log_id`)AS COUNTID FROM `log_order` WHERE `status_borrow` = '1' AND `dim_uid` = '$dim_uid'");
    while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
        $COUNTID = $DB_user->COUNTID;
    }  
    return $COUNTID;
}

function get_count_order_user_2($dim_uid){
    require('connect.php');
    $stml = $con->query("SELECT COUNT(`log_id`)AS COUNTID FROM `log_order` WHERE (`status_borrow` = '3' OR `status_borrow` = '4' ) AND `dim_uid` = '$dim_uid'");
    while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
        $COUNTID = $DB_user->COUNTID;
    }  
    return $COUNTID;
}

function get_All_order_user($dim_uid){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `log_order` INNER JOIN `dim_teacher` ON `dim_teacher`.`dim_id` = `log_order`.`dim_tid` LEFT JOIN (SELECT `log_orderid` AS LOGOR, COUNT(`log_id`) AS COUNTID FROM `log_detailborrow` GROUP BY `log_orderid`)AS T1 ON T1.LOGOR = `log_order`.`log_id` WHERE `dim_uid` = '$dim_uid' AND `status_borrow` = '1' ");
    return $stml;
}


function get_All_order_user_2($dim_uid){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `log_order` LEFT JOIN (SELECT `log_orderid` AS LOGOR, COUNT(`log_id`) AS COUNTID FROM `log_detailborrow` GROUP BY `log_orderid`)AS T1 ON T1.LOGOR = `log_order`.`log_id` WHERE `dim_uid` = '$dim_uid' AND (`status_borrow` = '3' OR `status_borrow` = '4' )");
    return $stml;
}

function det_order_user($log_id){
    require('connect.php');
    $endT = time();
    $con->query("UPDATE `log_order` SET `status_borrow` = '5', `endT` = '$endT' WHERE `log_order`.`log_id` = '$log_id'");
    return $stml;
}

function get_day(){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `db_day`");
    while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
        $day = $DB_user->day;
    }  
    return $day;

}

function up_day($day){
    require('connect.php');
    $con->query("UPDATE `db_day` SET `day` = '$day' WHERE `db_day`.`id` = 1");
}

function up_waitback_Admin($return_note,$log_id){
    require('connect.php');
    $endT = time();
    $day_night = date("Y-m-d",$endT);
    $con->query("UPDATE `log_order` SET `status_borrow` = '6', `endT` = '$endT', `return_note` = '$return_note', `day_night` = '$day_night' WHERE `log_order`.`log_id` = '$log_id'");
    $stml = $con->query("SELECT * FROM `log_detailborrow`INNER JOIN `dim_product` ON `dim_product`.`dimProduct` = `log_detailborrow`.`dim_product` WHERE `log_orderid` = '$log_id'");
    while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
        $con->query("UPDATE `db_serialnumber` SET `status` = 'อยู่ในระบบ' WHERE `db_serialnumber`.`sid` = '$DB_user->sid'");
        $con->query("UPDATE `log_detailborrow` SET `endT` = '$endT' WHERE `log_detailborrow`.`log_id` = '$DB_user->log_id'");
    }  
}


function get_count_wait(){
    require('connect.php');
    $stml = $con->query("SELECT COUNT(`log_id`)AS COUNTID FROM `log_order` WHERE `status_borrow` = '4'");
    while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
        $COUNTID = $DB_user->COUNTID;
    }  
    return $COUNTID;
    
}


function graph_shows($year){
    require('connect.php');
    $stml = $con->query("SELECT`dim_product`.`pName` ,COUNT(`log_detailborrow`.`log_id`) AS COUNTID FROM `log_detailborrow`INNER JOIN `dim_product` ON `dim_product`.`dimProduct` =`log_detailborrow`.`dim_product` INNER JOIN `log_order` ON `log_order`.`log_id` = `log_detailborrow`.`log_orderid` WHERE `log_order`.`year` = '$year' GROUP BY `dim_product`.`pName`");
    return $stml ;
}


function graph_shows_2($year){
    require('connect.php');
    $stml = $con->query("SELECT DISTINCT `dim_teacher`.`title`,`dim_teacher`.`firstname`,`dim_teacher`.`lastname`,COUNTID FROM `log_order` INNER JOIN (SELECT `dim_tid`,COUNT(`log_id`) AS COUNTID FROM `log_order` INNER JOIN `dim_teacher` ON `dim_teacher`.`dim_id` = `log_order`.`dim_tid` WHERE NOT ISNULL(`endT`) GROUP BY `dim_tid`)AS T1 ON T1.`dim_tid` = `log_order`.`dim_tid` INNER JOIN `dim_teacher` ON `dim_teacher`.`dim_id` = `log_order`.`dim_tid` WHERE `log_order`.`year` = '$year'");
    return $stml ;
}

function get_Y(){
    require('connect.php');
    $stml = $con->query("SELECT DISTINCT`year` FROM `log_order`");
    return $stml;
}


function get_T(){
    require('connect.php');
    $stml = $con->query("SELECT COUNT(`tid`)AS COUNT_T FROM `db_teacher`");
    while ($DB_user = $stml->fetch(PDO::FETCH_OBJ)){
        $COUNT_T = $DB_user->COUNT_T;
    }  
    return $COUNT_T;
}

function Add_DIM_teache($tid,$formalId,$title,$firstname,$lastname,$email){
    require('connect.php');
    $con->query("INSERT INTO `dim_teacher` (`dim_id`, `tid`, `formalId`, `title`, `firstname`, `lastname`, `email`) 
    VALUES (NULL, '$tid', '$formalId', '$title', '$firstname', '$lastname', '$email')");
}


function add_db_teache($formalId,$title,$firstname,$lastname,$email){
    require('connect.php');
    $con->query("INSERT INTO `db_teacher` (`tid`, `formalId`, `title`, `firstname`, `lastname`, `email`) VALUES (NULL, '$formalId', '$title', '$firstname', '$lastname', '$email')");
    $stml = $con->query("select max(tid)AS tid from `db_teacher`");
    while ($db_teacher = $stml->fetch(PDO::FETCH_OBJ)){
        $tid = $db_teacher->tid;
        Add_DIM_teache($tid,$formalId,$title,$firstname,$lastname,$email);
    }  
}

function get_All_t(){
    require('connect.php');
    $stml = $con->query("SELECT * FROM `db_teacher`");
    return $stml;
}

function del_db_t($tid){
    require('connect.php');
    $con->query("DELETE FROM `db_teacher` WHERE `db_teacher`.`tid` = '$tid'");
}
?>