-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 26, 2020 at 12:01 AM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.2.28-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_10`
--

-- --------------------------------------------------------

--
-- Table structure for table `db_category`
--

CREATE TABLE `db_category` (
  `cid` int(11) NOT NULL,
  `cName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_category`
--

INSERT INTO `db_category` (`cid`, `cName`) VALUES
(1, 'อุปกรณ์คอมพิวเตอร์'),
(2, 'อุปกรณ์อิเล็กทรอนิกส์'),
(3, 'กุญแจ'),
(4, 'ทั่วไป'),
(5, 'สายไฟ');

-- --------------------------------------------------------

--
-- Table structure for table `db_day`
--

CREATE TABLE `db_day` (
  `id` int(11) NOT NULL,
  `day` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_day`
--

INSERT INTO `db_day` (`id`, `day`) VALUES
(1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `db_product`
--

CREATE TABLE `db_product` (
  `pid` int(11) NOT NULL,
  `pName` varchar(255) NOT NULL,
  `cid` int(11) NOT NULL,
  `detail` text NOT NULL,
  `picPath` varchar(255) NOT NULL,
  `claim_Admin` tinyint(1) NOT NULL,
  `claim_Teacher` tinyint(1) NOT NULL,
  `claim_borrow` tinyint(1) NOT NULL,
  `lock` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_product`
--

INSERT INTO `db_product` (`pid`, `pName`, `cid`, `detail`, `picPath`, `claim_Admin`, `claim_Teacher`, `claim_borrow`, `lock`) VALUES
(1, 'จอ', 1, 'จอขนาดใหญ่', 'Add_image2.jpg', 1, 1, 1, 0),
(2, 'เมาส์', 1, 'เมาส์พิเศษ', '', 0, 1, 1, 0),
(3, 'กล้อง', 2, '', 'Canon-EOS-M50_2.jpg', 1, 1, 1, 0),
(4, 'สายแลน', 2, 'เป็นสายสีฟ้า', '', 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `db_serialnumber`
--

CREATE TABLE `db_serialnumber` (
  `sid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `serialNum` varchar(50) NOT NULL,
  `status` enum('ถูกยืม','อยู่ในระบบ') NOT NULL,
  `lock_ser` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_serialnumber`
--

INSERT INTO `db_serialnumber` (`sid`, `pid`, `serialNum`, `status`, `lock_ser`) VALUES
(1, 1, 'E0111012141', 'ถูกยืม', 0),
(2, 2, 'E1235471234', 'อยู่ในระบบ', 0),
(3, 3, 'E1247621445', 'อยู่ในระบบ', 0),
(4, 4, 'E123456789', 'อยู่ในระบบ', 0),
(5, 3, 'E1247621446', 'อยู่ในระบบ', 0),
(6, 2, '333333', 'อยู่ในระบบ', 0),
(7, 4, 'E123456788', 'อยู่ในระบบ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `db_teacher`
--

CREATE TABLE `db_teacher` (
  `tid` int(11) NOT NULL,
  `formalId` varchar(50) NOT NULL,
  `title` enum('นาย','นาง','นางสาว') NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_teacher`
--

INSERT INTO `db_teacher` (`tid`, `formalId`, `title`, `firstname`, `lastname`, `email`) VALUES
(1, 'fengncn', 'นางสาว', 'นุชนาฏ', 'สัตยากวี', 'fengncn@ku.ac.th'),
(5, '6020501281', 'นางสาว', 'จินต์จุทา ', 'วงโคตร', 'jinjutha.w@ku.th');

-- --------------------------------------------------------

--
-- Table structure for table `db_user`
--

CREATE TABLE `db_user` (
  `uid` int(11) NOT NULL,
  `formalId` varchar(50) NOT NULL,
  `title` enum('นาย','นาง','นางสาว') NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `status` enum('1','2','3') NOT NULL COMMENT '1 อาจารย์ 2 เจ้าหน้าที่ 3 ผู้ยืม',
  `isAdmin` tinyint(1) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `db_user`
--

INSERT INTO `db_user` (`uid`, `formalId`, `title`, `firstname`, `lastname`, `status`, `isAdmin`, `email`) VALUES
(1, 'fengsstc', 'นางสาว', 'ศศิธร', 'ชลรัตน์อมฤต', '2', 1, 'fengsstc@ku.ac.th'),
(2, '6020501418', 'นางสาว', 'ศิริพร', 'ผุลลาวงษ์', '2', 1, 'siripron.po@ku.th'),
(3, '6020503895', 'นาย', 'วัชระ', 'ศิลภมร', '3', 0, 'vatchala.s@ku.th'),
(4, '6020501281', 'นางสาว', 'จินต์จุฑา', 'วรโคตร', '1', 0, 'jinjutha.w@ku.th'),
(5, 'fengncn', 'นางสาว', 'นุชนาฎ', 'สัตยากวี', '1', 0, 'fengncn@ku.ac.th'),
(6, '6020500241', 'นางสาว', 'นภัสสร', 'มุกดา', '3', 0, 'naphatsorn.m@ku.th'),
(7, '6020500373', 'นาย', 'ใบชา', 'เจนจบวิทยา', '3', 0, 'baicha.j@ku.th'),
(8, '6020500381', 'นาย', 'ภาณุภัสส์', 'ธนัชญ์สุธาโชติ', '3', 0, 'phanuphat.t@ku.th');

-- --------------------------------------------------------

--
-- Table structure for table `dim_product`
--

CREATE TABLE `dim_product` (
  `dimProduct` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `pName` varchar(50) NOT NULL,
  `cName` varchar(50) NOT NULL,
  `detail` text NOT NULL,
  `serialNum` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dim_product`
--

INSERT INTO `dim_product` (`dimProduct`, `pid`, `cid`, `sid`, `pName`, `cName`, `detail`, `serialNum`) VALUES
(1, 1, 1, 1, 'จอ', 'อุปกรณ์คอมพิวเตอร์', 'จอขนาดใหญ่', 'E0111012141'),
(2, 2, 1, 2, 'เมาส์', 'อุปกรณ์คอมพิวเตอร์', 'เมาส์พิเศษ', 'E1235471234'),
(3, 3, 2, 3, 'กล้อง', 'อุปกรณ์อิเล็กทรอนิกส์', '', 'E1247621445'),
(4, 4, 2, 4, 'สายแลน', 'อุปกรณ์อิเล็กทรอนิกส์', 'เป็นสายสีฟ้า', 'E123456789'),
(5, 3, 2, 5, 'กล้อง', 'อุปกรณ์อิเล็กทรอนิกส์', '', 'E1247621446'),
(6, 2, 1, 6, 'เมาส์', 'อุปกรณ์คอมพิวเตอร์', 'เมาส์พิเศษ', '333333'),
(7, 4, 2, 7, 'สายแลน', 'อุปกรณ์อิเล็กทรอนิกส์', 'เป็นสายสีฟ้า', 'E123456788');

-- --------------------------------------------------------

--
-- Table structure for table `dim_teacher`
--

CREATE TABLE `dim_teacher` (
  `dim_id` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `formalId` varchar(50) NOT NULL,
  `title` enum('นาย','นาง','นางสาว') NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dim_teacher`
--

INSERT INTO `dim_teacher` (`dim_id`, `tid`, `formalId`, `title`, `firstname`, `lastname`, `email`) VALUES
(1, 1, 'fengncn', 'นางสาว', 'นุชนาฏ', 'สัตยากวี', 'fengncn@ku.ac.th'),
(2, 2, '6020503895', 'นาง', 'วัชระ', 'ศิลภมร', 'fam25850@gmail.com'),
(4, 5, '6020501281', 'นางสาว', 'จินต์จุทา ', 'วงโคตร', 'jinjutha.w@ku.th');

-- --------------------------------------------------------

--
-- Table structure for table `dim_user`
--

CREATE TABLE `dim_user` (
  `dim_id` int(11) NOT NULL,
  `stCode` varchar(50) NOT NULL,
  `uid` int(11) NOT NULL,
  `title` enum('นาย','นาง','นางสาว') NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `status` enum('1','2','3') NOT NULL COMMENT '1 อาจารย์ 2 เเอดมิน 3 ผู้ยืม',
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dim_user`
--

INSERT INTO `dim_user` (`dim_id`, `stCode`, `uid`, `title`, `firstname`, `lastname`, `status`, `email`) VALUES
(1, 'fengsstc', 1, 'นางสาว', 'ศศิธร', 'ชลรัตน์อมฤต', '2', 'fengsstc@ku.ac.th'),
(2, '6020501418', 2, 'นางสาว', 'ศิริพร', 'ผุลลาวงษ์', '2', 'siripron.po@ku.th'),
(3, '6020503895', 3, 'นาย', 'วัชระ', 'ศิลภมร', '3', 'vatchala.s@ku.th'),
(4, '6020501281', 4, 'นางสาว', 'จินต์จุฑา', 'วรโคตร', '1', 'jinjutha.w@ku.th'),
(5, '6020500241', 6, 'นางสาว', 'นภัสสร', 'มุกดา', '3', 'naphatsorn.m@ku.th'),
(6, '6020500373', 7, 'นาย', 'ใบชา', 'เจนจบวิทยา', '3', 'baicha.j@ku.th'),
(7, '6020500381', 8, 'นาย', 'ภาณุภัสส์', 'ธนัชญ์สุธาโชติ', '3', 'phanuphat.t@ku.th');

-- --------------------------------------------------------

--
-- Table structure for table `log_detailborrow`
--

CREATE TABLE `log_detailborrow` (
  `log_id` int(11) NOT NULL,
  `log_orderid` int(11) NOT NULL,
  `borrowNum` int(11) NOT NULL,
  `startT` int(11) NOT NULL,
  `endT` int(11) DEFAULT NULL,
  `dim_product` int(11) DEFAULT NULL,
  `db_product_borrow` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `log_detailborrow`
--

INSERT INTO `log_detailborrow` (`log_id`, `log_orderid`, `borrowNum`, `startT`, `endT`, `dim_product`, `db_product_borrow`) VALUES
(1, 1, 1, 1585132466, 1585132812, 3, 3),
(2, 2, 1, 1585132872, 1585146182, 2, 2),
(3, 3, 1, 1585133035, 1585146184, 3, 3),
(4, 3, 1, 1585133035, 1585146184, 4, 4),
(5, 3, 1, 1585133705, NULL, NULL, 3),
(6, 4, 1, 1585134100, 1585134222, 5, 3),
(7, 5, 1, 1585134252, 1585146187, 5, 3),
(9, 7, 1, 1585135158, NULL, NULL, 2),
(10, 8, 1, 1585136339, NULL, NULL, 2),
(11, 9, 1, 1585140538, NULL, NULL, 2),
(12, 10, 1, 1585140778, NULL, NULL, 4),
(13, 11, 1, 1585140929, 1585146190, 7, 4),
(14, 12, 1, 1585142196, NULL, NULL, 2),
(15, 13, 1, 1585142702, NULL, NULL, 2),
(16, 14, 1, 1585142796, NULL, NULL, 2),
(17, 15, 1, 1585145726, 1585146117, 6, 2),
(18, 16, 1, 1585146991, 1585149210, 3, 3),
(19, 17, 1, 1585148412, 1585149217, 7, 4),
(20, 18, 1, 1585149897, 1585149928, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `log_order`
--

CREATE TABLE `log_order` (
  `log_id` int(11) NOT NULL,
  `dim_uid` int(11) NOT NULL,
  `dim_tid` int(11) DEFAULT NULL,
  `status_borrow` enum('1','2','3','4','5','6') NOT NULL COMMENT '1=รอการอนุมัติ , 2=ไม่ผ่าน, 3 = รอมารับของ , 4 = รอส่งคืน,5 = ยืมไม่สำเร็จ	',
  `startT` int(11) NOT NULL,
  `endT` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `borrow_note` text,
  `confirm_note` text,
  `return_note` text,
  `year` int(11) NOT NULL,
  `date_sanction` date DEFAULT NULL,
  `date_Pick_up` date DEFAULT NULL,
  `day_night` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `log_order`
--

INSERT INTO `log_order` (`log_id`, `dim_uid`, `dim_tid`, `status_borrow`, `startT`, `endT`, `date`, `borrow_note`, `confirm_note`, `return_note`, `year`, `date_sanction`, `date_Pick_up`, `day_night`) VALUES
(1, 2, NULL, '6', 1585132466, 1585132812, '2020-03-25', '', NULL, '', 2020, NULL, NULL, '2020-03-25'),
(2, 4, NULL, '6', 1585132872, 1585146182, '2020-03-25', '', NULL, '', 2020, NULL, '2020-03-25', '2020-03-25'),
(3, 2, NULL, '6', 1585133035, 1585146184, '2020-03-25', '', NULL, '', 2020, NULL, NULL, '2020-03-25'),
(4, 3, NULL, '6', 1585134100, 1585134222, '2020-03-25', 'จะยืม', NULL, '', 2020, NULL, NULL, '2020-03-25'),
(5, 3, NULL, '6', 1585134252, 1585146187, '2020-03-25', 'ทดสอบ', NULL, '', 2020, NULL, NULL, '2020-03-25'),
(11, 5, 4, '6', 1585140929, 1585146190, '2020-03-25', 'ยืมได้', '', '', 2020, '2020-03-25', '2020-03-25', '2020-03-25'),
(12, 5, 4, '5', 1585142196, NULL, '2020-03-25', 'กกก', 'ขอเกินที่ตกลง', NULL, 2020, NULL, '2020-03-25', NULL),
(14, 3, 4, '6', 1585142796, 1585142796, '2020-03-25', 'หหห', 'ไม่ให้', 'คืน', 2020, '2020-03-19', '2020-03-25', '2020-03-24'),
(15, 4, NULL, '6', 1585145726, 1585146117, '2020-03-25', '', NULL, '', 2020, NULL, '2020-03-25', '2020-03-25'),
(16, 4, NULL, '6', 1585146991, 1585149210, '2020-03-25', '', NULL, '', 2020, NULL, '2020-03-25', '2020-03-25'),
(17, 5, 4, '6', 1585148412, 1585149217, '2020-03-25', '', '', '', 2020, '2020-03-25', '2020-03-25', '2020-03-25'),
(18, 2, NULL, '6', 1585149897, 1585149928, '2020-03-25', '-', NULL, '', 2020, NULL, NULL, '2020-03-25');

-- --------------------------------------------------------

--
-- Table structure for table `log_suggestion`
--

CREATE TABLE `log_suggestion` (
  `sugid` int(11) NOT NULL,
  `suggestion` text NOT NULL,
  `startT` int(11) NOT NULL,
  `endT` int(11) DEFAULT NULL,
  `date_send` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `log_suggestion`
--

INSERT INTO `log_suggestion` (`sugid`, `suggestion`, `startT`, `endT`, `date_send`) VALUES
(1, 'ต้องการสายแลนเพิ่ม', 1585127971, NULL, '2020-03-25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `db_category`
--
ALTER TABLE `db_category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `db_day`
--
ALTER TABLE `db_day`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_product`
--
ALTER TABLE `db_product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `db_serialnumber`
--
ALTER TABLE `db_serialnumber`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `db_teacher`
--
ALTER TABLE `db_teacher`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `db_user`
--
ALTER TABLE `db_user`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `dim_product`
--
ALTER TABLE `dim_product`
  ADD PRIMARY KEY (`dimProduct`);

--
-- Indexes for table `dim_teacher`
--
ALTER TABLE `dim_teacher`
  ADD PRIMARY KEY (`dim_id`);

--
-- Indexes for table `dim_user`
--
ALTER TABLE `dim_user`
  ADD PRIMARY KEY (`dim_id`);

--
-- Indexes for table `log_detailborrow`
--
ALTER TABLE `log_detailborrow`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `log_order`
--
ALTER TABLE `log_order`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `log_suggestion`
--
ALTER TABLE `log_suggestion`
  ADD PRIMARY KEY (`sugid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `db_category`
--
ALTER TABLE `db_category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `db_day`
--
ALTER TABLE `db_day`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `db_product`
--
ALTER TABLE `db_product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `db_serialnumber`
--
ALTER TABLE `db_serialnumber`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `db_teacher`
--
ALTER TABLE `db_teacher`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `db_user`
--
ALTER TABLE `db_user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `dim_product`
--
ALTER TABLE `dim_product`
  MODIFY `dimProduct` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `dim_teacher`
--
ALTER TABLE `dim_teacher`
  MODIFY `dim_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dim_user`
--
ALTER TABLE `dim_user`
  MODIFY `dim_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `log_detailborrow`
--
ALTER TABLE `log_detailborrow`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `log_order`
--
ALTER TABLE `log_order`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `log_suggestion`
--
ALTER TABLE `log_suggestion`
  MODIFY `sugid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
